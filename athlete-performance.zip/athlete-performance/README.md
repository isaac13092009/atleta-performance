# ATHLETE PERFORMANCE

App nativo (React Native + Expo, TypeScript) para Android e iOS: musculação, futebol, sono, recuperação, agenda e planejamento inteligente de treinos.

## Rodar
```bash
npm install
npx expo start          # abra no Expo Go (celular) ou emulador
```

## Gerar o app instalável
```bash
npm i -g eas-cli && eas login
eas build -p android --profile preview   # gera APK instalável
eas build -p ios --profile production    # exige conta Apple Developer
```
Para notificações remotas (push) configure FCM/APNs via EAS; os lembretes locais já funcionam sem isso.

## Nuvem (Supabase) — login, sincronização, backup
1. Crie um projeto em supabase.com e rode `supabase/schema.sql` no SQL Editor (tabelas com Row Level Security: cada usuário só acessa os próprios dados).
2. Em `app.json` preencha `expo.extra.supabaseUrl` e `expo.extra.supabaseAnonKey`.
3. Entre em **Mais → Perfil → Conta e nuvem**. Recuperação de senha por e-mail incluída.

Sem a nuvem configurada o app funciona 100% offline (dados em AsyncStorage). Com login, toda alteração entra numa fila e sincroniza ao reconectar (last-write-wins por `updatedAt`; exclusões são sincronizadas).

## O que está implementado
- Dashboard: recomendação do dia, recuperação/fadiga, peso, sono, último treino, carga semanal, próximo jogo, histórico.
- Academia: exercícios, planos por dia/grupo, registro de séries/reps/carga/descanso/observações/data-hora, sugestão automática de progressão de carga (+2,5 kg superiores / +5 kg pernas quando todas as reps foram cumpridas), peso corporal, gráficos por semana/mês, volume por grupo.
- Futebol: partidas, gols (minuto, tipo, pé, assistência, resultado), assistências, titular/reserva, filtros por temporada/mês/competição, gráficos.
- Agenda: 6 tipos de evento, detecção de conflitos, carga planejada por dia.
- IA (motor de regras transparente em `src/engine.ts`): considera jogos futuros, jogo de ontem, grupos treinados nas últimas 48h, sono, dor/cansaço relatados e recuperação estimada. Nunca recomenda treino intenso com recuperação baixa ou cansaço alto, e sempre mostra a justificativa.
- Sono, Recuperação, Relatórios (gráficos + PDF), Perfil, Notificações, Backup JSON.

## Limitações honestas
- **Wellhub:** não há API pública para o atleta ler seus check-ins; o app não usa scraping nem pede credenciais. Há confirmação manual e importação de CSV (`data,hora,academia,duração`). A integração oficial depende de parceria/autorização do Wellhub.
- **Tempo de tela:** Android (UsageStatsManager, permissão especial) e iOS (Screen Time/FamilyControls, entitlement da Apple) exigem módulos nativos que **não** estão incluídos. Hoje o uso de madrugada é registrado manualmente e tratado só como indicador indireto — o app nunca afirma que você dormiu por ter parado de usar o celular.
- **Relógios/plataformas de saúde (Health Connect, HealthKit):** não incluídos nesta versão (exigem build nativo/dev client). A arquitetura (`SleepEntry.source`) já prevê a origem `saude`.
- Recuperação e fadiga são **estimativas** a partir dos seus registros, não medições clínicas.
- Datas/horas são digitadas como AAAA-MM-DD e HH:MM (sem seletor nativo ainda).
- Não foi testado em aparelho físico nesta sessão: só typecheck e bundle Android.

## APK sem mexer em código (GitHub Actions)
1. Crie um repositório vazio no GitHub e envie todos os arquivos desta pasta (arrastar e soltar em "uploading an existing file" funciona; inclua a pasta `.github`).
2. Aba **Actions → Gerar APK → Run workflow**. Em ~10–15 min, baixe `athlete-performance-apk` em *Artifacts*, descompacte e instale o `.apk` no Android (permita "fontes desconhecidas").
