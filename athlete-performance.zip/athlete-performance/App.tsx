import React, { useEffect } from 'react';
import { Text, View, Pressable } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { colors } from './src/theme';
import { restoreSession, startAutoSync, syncNow } from './src/sync';
import { rescheduleAll } from './src/notifications';
import { useStore } from './src/store';
import Dashboard from './src/screens/Dashboard';
import Gym from './src/screens/Gym';
import Football from './src/screens/Football';
import Calendar from './src/screens/Calendar';
import Sleep from './src/screens/Sleep';
import Recovery from './src/screens/Recovery';
import Plan from './src/screens/Plan';
import Reports from './src/screens/Reports';
import Profile from './src/screens/Profile';
import Wellhub from './src/screens/Wellhub';
import { Card, H1, H2, Muted, Screen } from './src/ui';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const theme = {
  ...DarkTheme,
  colors: { ...DarkTheme.colors, background: colors.bg, card: colors.navy, border: colors.border, primary: colors.blue, text: colors.text },
};

const MENU: { name: string; label: string; desc: string }[] = [
  { name: 'Plano', label: 'Plano inteligente (IA)', desc: 'Recomendações com justificativas para a semana' },
  { name: 'Sono', label: 'Sono', desc: 'Registro, média semanal, lembretes e tela' },
  { name: 'Recuperação', label: 'Recuperação e fadiga', desc: 'Indicadores estimados e recomendações' },
  { name: 'Relatórios', label: 'Relatórios', desc: 'Gráficos por período e exportação em PDF' },
  { name: 'Wellhub', label: 'Wellhub', desc: 'Visitas à academia' },
  { name: 'Perfil', label: 'Perfil, notificações e conta', desc: 'Dados do atleta, nuvem e backup' },
];

function More({ navigation }: any) {
  return (
    <Screen>
      <H1>Mais</H1>
      {MENU.map((m) => (
        <Card key={m.name} onPress={() => navigation.navigate(m.name)}>
          <H2>{m.label}</H2>
          <Muted>{m.desc}</Muted>
        </Card>
      ))}
    </Screen>
  );
}

function MoreStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.bg } }}>
      <Stack.Screen name="Menu" component={More} />
      <Stack.Screen name="Plano" component={Plan} />
      <Stack.Screen name="Sono" component={Sleep} />
      <Stack.Screen name="Recuperação" component={Recovery} />
      <Stack.Screen name="Relatórios" component={Reports} />
      <Stack.Screen name="Wellhub" component={Wellhub} />
      <Stack.Screen name="Perfil" component={Profile} />
    </Stack.Navigator>
  );
}

const icon: Record<string, string> = { Início: '◉', Academia: '▥', Futebol: '⚽', Agenda: '▦', Mais: '☰' };

export default function App() {
  useEffect(() => {
    let stop: (() => void) | undefined;
    (async () => {
      await restoreSession();
      if (useStore.getState().userId) void syncNow();
      stop = startAutoSync();
      void rescheduleAll();
    })();
    return () => stop?.();
  }, []);

  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <NavigationContainer theme={theme}>
        <Tab.Navigator
          screenOptions={({ route }) => ({
            headerShown: false,
            tabBarStyle: { backgroundColor: colors.navy, borderTopColor: colors.border },
            tabBarActiveTintColor: colors.blue,
            tabBarInactiveTintColor: colors.dim,
            tabBarIcon: ({ color }) => <Text style={{ color, fontSize: 18 }}>{icon[route.name]}</Text>,
          })}
        >
          <Tab.Screen name="Início" component={Dashboard} />
          <Tab.Screen name="Academia" component={Gym} />
          <Tab.Screen name="Futebol" component={Football} />
          <Tab.Screen name="Agenda" component={Calendar} />
          <Tab.Screen name="Mais" component={MoreStack} />
        </Tab.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
