-- ATHLETE PERFORMANCE — schema Supabase (execute no SQL Editor)
create table if not exists public.records (
  user_id uuid not null references auth.users(id) on delete cascade,
  collection text not null,
  id text not null,
  data jsonb not null,
  updated_at bigint not null,
  deleted boolean not null default false,
  primary key (user_id, collection, id)
);
create table if not exists public.athlete_profile (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null,
  updated_at bigint not null
);
alter table public.records enable row level security;
alter table public.athlete_profile enable row level security;

create policy "records_owner" on public.records
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "profile_owner" on public.athlete_profile
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index if not exists records_user_updated on public.records (user_id, updated_at);
