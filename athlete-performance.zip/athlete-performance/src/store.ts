import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  Assist, Base, CalEvent, Exercise, Feeling, Goal, Match, Profile, ScreenEvent,
  Settings, SleepEntry, TrainingPlan, WeightEntry, WellhubVisit, WorkoutSession,
} from './types';
import { uid } from './utils';

export interface Collections {
  exercises: Exercise[];
  plans: TrainingPlan[];
  sessions: WorkoutSession[];
  weights: WeightEntry[];
  matches: Match[];
  goals: Goal[];
  assists: Assist[];
  sleeps: SleepEntry[];
  screenEvents: ScreenEvent[];
  events: CalEvent[];
  feelings: Feeling[];
  visits: WellhubVisit[];
}
export type ColName = keyof Collections;
export const COLLECTIONS: ColName[] = [
  'exercises', 'plans', 'sessions', 'weights', 'matches', 'goals', 'assists',
  'sleeps', 'screenEvents', 'events', 'feelings', 'visits',
];

const emptyCollections = (): Collections => ({
  exercises: [], plans: [], sessions: [], weights: [], matches: [], goals: [],
  assists: [], sleeps: [], screenEvents: [], events: [], feelings: [], visits: [],
});

export const defaultProfile: Profile = {
  name: '', age: null, heightCm: null, position: '', goals: '', history: '',
  preferredTimes: '', weeklyAvailability: null, bedtime: '23:00', updatedAt: 0,
};
export const defaultSettings: Settings = {
  notif: {
    train: true, match: true, sleep: true, rest: true,
    weight: false, stats: false, reco: true, conflict: true,
  },
  trainTime: '18:00',
  weightTime: '07:30',
  sleepLeadMin: 30,
  lastSync: null,
};

interface State extends Collections {
  profile: Profile;
  settings: Settings;
  userId: string | null;
  email: string | null;
  onboarded: boolean;
  dirty: Record<string, number>; // "col:id" -> updatedAt pendente de envio
  upsert: <K extends ColName>(col: K, item: Omit<Collections[K][number], 'id' | 'updatedAt'> & { id?: string }) => string;
  remove: (col: ColName, id: string) => void;
  setProfile: (p: Partial<Profile>) => void;
  setSettings: (s: Partial<Settings>) => void;
  setAuth: (userId: string | null, email: string | null) => void;
  setOnboarded: () => void;
  mergeRemote: (col: ColName, rows: Base[]) => void;
  mergeRemoteProfile: (p: Profile) => void;
  clearDirty: (keys: string[]) => void;
  wipeLocal: () => void;
  exportAll: () => string;
  importAll: (json: string) => boolean;
}

export const useStore = create<State>()(
  persist(
    (set, get) => ({
      ...emptyCollections(),
      profile: defaultProfile,
      settings: defaultSettings,
      userId: null,
      email: null,
      onboarded: false,
      dirty: {},

      upsert: (col, item) => {
        const id = (item as { id?: string }).id ?? uid();
        const now = Date.now();
        const full = { ...(item as object), id, updatedAt: now } as Base;
        set((s) => {
          const list = (s[col] as Base[]).slice();
          const i = list.findIndex((x) => x.id === id);
          if (i >= 0) list[i] = { ...list[i], ...full };
          else list.push(full);
          return {
            [col]: list,
            dirty: { ...s.dirty, [`${col}:${id}`]: now },
          } as Partial<State>;
        });
        return id;
      },

      remove: (col, id) => {
        const now = Date.now();
        set((s) => {
          const list = (s[col] as Base[]).map((x) =>
            x.id === id ? { ...x, deleted: true, updatedAt: now } : x,
          );
          return {
            [col]: list,
            dirty: { ...s.dirty, [`${col}:${id}`]: now },
          } as Partial<State>;
        });
      },

      setProfile: (p) =>
        set((s) => ({
          profile: { ...s.profile, ...p, updatedAt: Date.now() },
          dirty: { ...s.dirty, 'profile:me': Date.now() },
        })),
      setSettings: (p) => set((s) => ({ settings: { ...s.settings, ...p } })),
      setAuth: (userId, email) => set({ userId, email }),
      setOnboarded: () => set({ onboarded: true }),

      mergeRemote: (col, rows) =>
        set((s) => {
          const list = (s[col] as Base[]).slice();
          for (const r of rows) {
            const i = list.findIndex((x) => x.id === r.id);
            if (i < 0) list.push(r);
            else if (r.updatedAt > list[i].updatedAt) list[i] = r;
          }
          return { [col]: list } as Partial<State>;
        }),
      mergeRemoteProfile: (p) =>
        set((s) => (p.updatedAt > s.profile.updatedAt ? { profile: p } : {})),
      clearDirty: (keys) =>
        set((s) => {
          const d = { ...s.dirty };
          keys.forEach((k) => delete d[k]);
          return { dirty: d };
        }),

      wipeLocal: () =>
        set({
          ...emptyCollections(),
          profile: defaultProfile,
          settings: defaultSettings,
          dirty: {},
          onboarded: false,
        }),

      exportAll: () => {
        const s = get();
        const out: Record<string, unknown> = { version: 1, profile: s.profile };
        COLLECTIONS.forEach((c) => (out[c] = s[c]));
        return JSON.stringify(out);
      },
      importAll: (json) => {
        try {
          const d = JSON.parse(json);
          if (!d || d.version !== 1) return false;
          const patch: Record<string, unknown> = {};
          const dirty: Record<string, number> = { ...get().dirty };
          COLLECTIONS.forEach((c) => {
            if (Array.isArray(d[c])) {
              patch[c] = d[c];
              d[c].forEach((r: Base) => (dirty[`${c}:${r.id}`] = Date.now()));
            }
          });
          if (d.profile) patch.profile = d.profile;
          set({ ...(patch as Partial<State>), dirty });
          return true;
        } catch {
          return false;
        }
      },
    }),
    {
      name: 'athlete-performance-v1',
      storage: createJSONStorage(() => AsyncStorage),
      version: 1,
    },
  ),
);

// Seletores que ignoram registros removidos
export const live = <T extends Base>(a: T[]): T[] => a.filter((x) => !x.deleted);
