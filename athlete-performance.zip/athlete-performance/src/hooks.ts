import { useMemo } from 'react';
import { useStore, live } from './store';
import { computeRecovery, recommend } from './engine';
import { PlanDay } from './types';

export function useData() {
  const raw = useStore();
  return useMemo(
    () => ({
      exercises: live(raw.exercises),
      plans: live(raw.plans),
      sessions: live(raw.sessions).sort((a, b) => b.startedAt - a.startedAt),
      weights: live(raw.weights).sort((a, b) => a.at - b.at),
      matches: live(raw.matches).sort((a, b) => b.date.localeCompare(a.date)),
      goals: live(raw.goals),
      assists: live(raw.assists),
      sleeps: live(raw.sleeps).sort((a, b) => b.wakeAt - a.wakeAt),
      screenEvents: live(raw.screenEvents),
      events: live(raw.events).sort((a, b) => a.start - b.start),
      feelings: live(raw.feelings).sort((a, b) => b.at - a.at),
      visits: live(raw.visits).sort((a, b) => b.at - a.at),
      profile: raw.profile,
      settings: raw.settings,
    }),
    [
      raw.exercises, raw.plans, raw.sessions, raw.weights, raw.matches, raw.goals, raw.assists,
      raw.sleeps, raw.screenEvents, raw.events, raw.feelings, raw.visits, raw.profile, raw.settings,
    ],
  );
}

export function useAdvice(date = Date.now(), future = false) {
  const d = useData();
  return useMemo(() => {
    const planDays: PlanDay[] = d.plans.flatMap((p) => p.days);
    const recovery = computeRecovery(date, d.sleeps, d.sessions, d.matches, d.feelings);
    const rec = recommend({
      date, events: d.events, sessions: d.sessions, matches: d.matches, sleeps: d.sleeps,
      feelings: d.feelings, planDays, recovery, future,
    });
    return { recovery, rec, planDays };
  }, [d, date, future]);
}
