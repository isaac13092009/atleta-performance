export const colors = {
  bg: '#05080F',
  navy: '#0A1226',
  card: '#0D1730',
  cardAlt: '#111F3F',
  border: '#1B2A4D',
  blue: '#2F6BFF',
  blueSoft: '#5B8CFF',
  text: '#FFFFFF',
  muted: '#8E9BB8',
  dim: '#5C6A8A',
  ok: '#2FD39A',
  warn: '#FFB020',
  bad: '#FF5470',
};

export const radius = { sm: 8, md: 14, lg: 20 };
export const space = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24 };
