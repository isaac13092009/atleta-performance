export type ID = string;

export interface Base {
  id: ID;
  updatedAt: number;
  deleted?: boolean;
}

export type MuscleGroup =
  | 'Peito' | 'Costas' | 'Ombros' | 'Bíceps' | 'Tríceps'
  | 'Quadríceps' | 'Posterior' | 'Glúteos' | 'Panturrilha' | 'Abdômen';

export const MUSCLE_GROUPS: MuscleGroup[] = [
  'Peito', 'Costas', 'Ombros', 'Bíceps', 'Tríceps',
  'Quadríceps', 'Posterior', 'Glúteos', 'Panturrilha', 'Abdômen',
];
export const LEG_GROUPS: MuscleGroup[] = ['Quadríceps', 'Posterior', 'Glúteos', 'Panturrilha'];

export interface Profile {
  name: string;
  age: number | null;
  heightCm: number | null;
  position: string;
  goals: string;
  history: string;
  preferredTimes: string;
  weeklyAvailability: number | null; // dias por semana
  bedtime: string; // HH:MM
  updatedAt: number;
}

export interface Exercise extends Base {
  name: string;
  group: MuscleGroup;
}

export interface PlanExercise {
  exerciseId: ID;
  sets: number;
  reps: number;
  restSec: number;
  startKg: number;
}
export interface PlanDay {
  id: ID;
  name: string; // ex: "A - Peito/Tríceps"
  groups: MuscleGroup[];
  exercises: PlanExercise[];
}
export interface TrainingPlan extends Base {
  name: string;
  days: PlanDay[];
}

export interface SetEntry {
  reps: number;
  kg: number;
}
export interface ExerciseLog {
  exerciseId: ID;
  name: string;
  group: MuscleGroup;
  sets: SetEntry[];
  restSec: number;
  notes: string;
}
export interface WorkoutSession extends Base {
  startedAt: number;
  durationMin: number;
  planDayName: string;
  rpe: number | null; // percepção de esforço 1-10
  logs: ExerciseLog[];
  wellhubVisitId?: ID;
}

export interface WeightEntry extends Base {
  at: number;
  kg: number;
}

export type MatchType = 'jogo' | 'treino';
export interface Match extends Base {
  date: string; // YYYY-MM-DD
  opponent: string;
  competition: string;
  minutes: number;
  starter: boolean;
  intensity: number; // 1-10
  scoreFor: number;
  scoreAgainst: number;
}
export interface Goal extends Base {
  matchId: ID;
  minute: number;
  kind: string; // tipo de gol
  foot: 'Direito' | 'Esquerdo' | 'Cabeça' | 'Outro';
  assistBy: string;
}
export interface Assist extends Base {
  matchId: ID;
  minute: number;
  note: string;
}

export interface SleepEntry extends Base {
  date: string; // data em que acordou YYYY-MM-DD
  bedAt: number;
  wakeAt: number;
  quality: number | null; // 1-5
  source: 'manual' | 'saude';
}
export interface ScreenEvent extends Base {
  at: number;
  note: string; // uso de celular de madrugada, informado/importado
}

export type CalType = 'musculacao' | 'futebol' | 'jogo' | 'descanso' | 'recuperacao' | 'avaliacao';
export interface CalEvent extends Base {
  type: CalType;
  title: string;
  start: number;
  durationMin: number;
  notes: string;
  intensity: number; // 1-10 esperado
  groups: MuscleGroup[];
}

export interface Feeling extends Base {
  at: number;
  fatigue: number; // 1-5
  soreness: number; // 1-5
  soreGroups: MuscleGroup[];
  note: string;
}

export interface WellhubVisit extends Base {
  at: number;
  gym: string;
  durationMin: number | null;
  source: 'manual' | 'importacao' | 'api';
  confirmed: boolean;
}

export interface Settings {
  notif: {
    train: boolean; match: boolean; sleep: boolean; rest: boolean;
    weight: boolean; stats: boolean; reco: boolean; conflict: boolean;
  };
  trainTime: string; // HH:MM
  weightTime: string;
  sleepLeadMin: number;
  lastSync: number | null;
}

export const CAL_LABEL: Record<CalType, string> = {
  musculacao: 'Musculação',
  futebol: 'Treino de futebol',
  jogo: 'Jogo',
  descanso: 'Descanso',
  recuperacao: 'Recuperação',
  avaliacao: 'Avaliação física',
};
