import React, { ReactNode, useState } from 'react';
import {
  Alert, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet,
  Text, TextInput, View, ViewStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, radius, space } from './theme';

export function Screen({ children, scroll = true }: { children: ReactNode; scroll?: boolean }) {
  const inner = scroll ? (
    <ScrollView contentContainerStyle={{ padding: space.lg, paddingBottom: 48 }} keyboardShouldPersistTaps="handled">
      {children}
    </ScrollView>
  ) : (
    <View style={{ flex: 1, padding: space.lg }}>{children}</View>
  );
  return (
    <SafeAreaView edges={['top']} style={{ flex: 1, backgroundColor: colors.bg }}>
      {inner}
    </SafeAreaView>
  );
}

export const H1 = ({ children }: { children: ReactNode }) => <Text style={s.h1}>{children}</Text>;
export const H2 = ({ children }: { children: ReactNode }) => <Text style={s.h2}>{children}</Text>;
export const Muted = ({ children, style }: { children: ReactNode; style?: object }) => (
  <Text style={[s.muted, style]}>{children}</Text>
);

export function Card({ children, style, onPress }: { children: ReactNode; style?: ViewStyle; onPress?: () => void }) {
  const C: React.ElementType = onPress ? Pressable : View;
  return (
    <C onPress={onPress} style={[s.card, style]}>
      {children}
    </C>
  );
}

export function Stat({ label, value, sub, color }: { label: string; value: string; sub?: string; color?: string }) {
  return (
    <Card style={{ flex: 1, minWidth: '46%' }}>
      <Text style={s.statLabel}>{label}</Text>
      <Text style={[s.statValue, color ? { color } : null]}>{value}</Text>
      {sub ? <Text style={s.statSub}>{sub}</Text> : null}
    </Card>
  );
}

export const Row = ({ children, style }: { children: ReactNode; style?: ViewStyle }) => (
  <View style={[{ flexDirection: 'row', gap: space.md, flexWrap: 'wrap' }, style]}>{children}</View>
);

export function Button({
  title, onPress, kind = 'primary', small, disabled,
}: { title: string; onPress: () => void; kind?: 'primary' | 'ghost' | 'danger'; small?: boolean; disabled?: boolean }) {
  const bg = kind === 'primary' ? colors.blue : kind === 'danger' ? 'transparent' : colors.cardAlt;
  const border = kind === 'danger' ? colors.bad : kind === 'ghost' ? colors.border : colors.blue;
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        s.btn,
        { backgroundColor: bg, borderColor: border, opacity: disabled ? 0.4 : pressed ? 0.8 : 1 },
        small && { paddingVertical: 8, paddingHorizontal: 12 },
      ]}
    >
      <Text style={[s.btnText, kind === 'danger' && { color: colors.bad }, small && { fontSize: 13 }]}>{title}</Text>
    </Pressable>
  );
}

export function Field({
  label, value, onChangeText, placeholder, keyboard, multiline, secure,
}: {
  label: string; value: string; onChangeText: (t: string) => void; placeholder?: string;
  keyboard?: 'default' | 'numeric' | 'decimal-pad' | 'email-address'; multiline?: boolean; secure?: boolean;
}) {
  return (
    <View style={{ marginBottom: space.md }}>
      <Text style={s.fieldLabel}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.dim}
        keyboardType={keyboard ?? 'default'}
        autoCapitalize={keyboard === 'email-address' || secure ? 'none' : 'sentences'}
        secureTextEntry={secure}
        multiline={multiline}
        style={[s.input, multiline && { minHeight: 70, textAlignVertical: 'top' }]}
      />
    </View>
  );
}

export function Chips<T extends string>({
  options, value, onChange, multi,
}: { options: readonly T[]; value: T[] | T | null; onChange: (v: T) => void; multi?: boolean }) {
  const sel = (o: T) => (multi ? (value as T[]).includes(o) : value === o);
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: space.md }}>
      {options.map((o) => (
        <Pressable key={o} onPress={() => onChange(o)} style={[s.chip, sel(o) && s.chipOn]}>
          <Text style={[s.chipText, sel(o) && { color: '#fff' }]}>{o}</Text>
        </Pressable>
      ))}
    </View>
  );
}

export function Scale({ label, value, onChange, max = 5 }: { label: string; value: number; onChange: (n: number) => void; max?: number }) {
  return (
    <View style={{ marginBottom: space.md }}>
      <Text style={s.fieldLabel}>{label}</Text>
      <View style={{ flexDirection: 'row', gap: 6 }}>
        {Array.from({ length: max }, (_, i) => i + 1).map((n) => (
          <Pressable key={n} onPress={() => onChange(n)} style={[s.scaleDot, n <= value && { backgroundColor: colors.blue, borderColor: colors.blue }]}>
            <Text style={{ color: n <= value ? '#fff' : colors.muted, fontWeight: '700', fontSize: 12 }}>{n}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

export function Sheet({ visible, onClose, title, children }: { visible: boolean; onClose: () => void; title: string; children: ReactNode }) {
  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: '#000A' }}>
        <View style={s.sheet}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: space.md }}>
            <Text style={s.h2}>{title}</Text>
            <Pressable onPress={onClose} hitSlop={12}><Text style={{ color: colors.muted, fontSize: 22 }}>✕</Text></Pressable>
          </View>
          <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingBottom: 24 }}>{children}</ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

export function Segmented<T extends string>({ options, value, onChange }: { options: { key: T; label: string }[]; value: T; onChange: (v: T) => void }) {
  return (
    <View style={s.seg}>
      {options.map((o) => (
        <Pressable key={o.key} onPress={() => onChange(o.key)} style={[s.segItem, value === o.key && { backgroundColor: colors.blue }]}>
          <Text style={{ color: value === o.key ? '#fff' : colors.muted, fontSize: 12, fontWeight: '600' }}>{o.label}</Text>
        </Pressable>
      ))}
    </View>
  );
}

export function Empty({ text }: { text: string }) {
  return (
    <View style={{ padding: space.xl, alignItems: 'center' }}>
      <Text style={{ color: colors.dim, textAlign: 'center' }}>{text}</Text>
    </View>
  );
}

export function Badge({ text, color = colors.blue }: { text: string; color?: string }) {
  return (
    <View style={{ borderColor: color, borderWidth: 1, borderRadius: 99, paddingHorizontal: 8, paddingVertical: 2, alignSelf: 'flex-start' }}>
      <Text style={{ color, fontSize: 11, fontWeight: '700' }}>{text}</Text>
    </View>
  );
}

export function confirm(title: string, msg: string, onYes: () => void) {
  Alert.alert(title, msg, [{ text: 'Cancelar', style: 'cancel' }, { text: 'Confirmar', style: 'destructive', onPress: onYes }]);
}

export function useForm<T extends object>(init: T) {
  const [v, setV] = useState<T>(init);
  const set = <K extends keyof T>(k: K, val: T[K]) => setV((p) => ({ ...p, [k]: val }));
  return { v, set, reset: () => setV(init), setAll: setV };
}

const s = StyleSheet.create({
  h1: { color: colors.text, fontSize: 26, fontWeight: '800', letterSpacing: 0.3, marginBottom: space.sm },
  h2: { color: colors.text, fontSize: 17, fontWeight: '700' },
  muted: { color: colors.muted, fontSize: 13 },
  card: { backgroundColor: colors.card, borderColor: colors.border, borderWidth: 1, borderRadius: radius.md, padding: space.lg, marginBottom: space.md },
  statLabel: { color: colors.muted, fontSize: 12, marginBottom: 4 },
  statValue: { color: colors.text, fontSize: 24, fontWeight: '800' },
  statSub: { color: colors.dim, fontSize: 11, marginTop: 2 },
  btn: { borderWidth: 1, borderRadius: radius.md, paddingVertical: 13, paddingHorizontal: 18, alignItems: 'center', marginBottom: space.sm },
  btnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  fieldLabel: { color: colors.muted, fontSize: 12, marginBottom: 6 },
  input: { backgroundColor: colors.navy, borderColor: colors.border, borderWidth: 1, borderRadius: radius.sm, color: colors.text, paddingHorizontal: 12, paddingVertical: 11, fontSize: 15 },
  chip: { borderColor: colors.border, borderWidth: 1, borderRadius: 99, paddingHorizontal: 12, paddingVertical: 7, backgroundColor: colors.navy },
  chipOn: { backgroundColor: colors.blue, borderColor: colors.blue },
  chipText: { color: colors.muted, fontSize: 13, fontWeight: '600' },
  scaleDot: { width: 34, height: 34, borderRadius: 17, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.navy },
  sheet: { backgroundColor: colors.card, borderTopLeftRadius: radius.lg, borderTopRightRadius: radius.lg, padding: space.lg, maxHeight: '90%', borderColor: colors.border, borderWidth: 1 },
  seg: { flexDirection: 'row', backgroundColor: colors.navy, borderRadius: radius.sm, padding: 3, marginBottom: space.md, borderColor: colors.border, borderWidth: 1 },
  segItem: { flex: 1, alignItems: 'center', paddingVertical: 7, borderRadius: 6 },
});
