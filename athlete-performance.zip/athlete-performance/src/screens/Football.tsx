import React, { useMemo, useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { Button, Card, Chips, Empty, Field, H1, H2, Muted, Row, Scale, Screen, Segmented, Sheet, Stat, confirm, useForm } from '../ui';
import { BarChart } from '../charts';
import { useData } from '../hooks';
import { useStore } from '../store';
import { colors } from '../theme';
import { parseDate, num, sum, ymd } from '../utils';

type Tab = 'resumo' | 'partidas' | 'gols';
const FEET = ['Direito', 'Esquerdo', 'Cabeça', 'Outro'] as const;
const GOAL_TYPES = ['Jogada', 'Chute de fora', 'Pênalti', 'Falta', 'Bola parada', 'Rebote', 'Contra-ataque', 'Outro'];
const MONTHS = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];

interface GoalDraft { minute: string; kind: string; foot: (typeof FEET)[number]; assistBy: string }

export default function Football() {
  const d = useData();
  const [tab, setTab] = useState<Tab>('resumo');
  const [season, setSeason] = useState<string>('Todas');
  const [month, setMonth] = useState<string>('Todos');
  const [comp, setComp] = useState<string>('Todas');
  const [open, setOpen] = useState(false);
  const f = useForm({ date: ymd(Date.now()), opponent: '', competition: '', minutes: '90', starter: true, intensity: 6, sf: '0', sa: '0', assists: '0' });
  const [goals, setGoals] = useState<GoalDraft[]>([]);
  const [err, setErr] = useState('');

  const seasons = ['Todas', ...[...new Set(d.matches.map((m) => m.date.slice(0, 4)))].sort().reverse()];
  const comps = ['Todas', ...[...new Set(d.matches.map((m) => m.competition).filter(Boolean))]];
  const filtered = d.matches.filter((m) =>
    (season === 'Todas' || m.date.startsWith(season)) &&
    (month === 'Todos' || m.date.slice(5, 7) === String(MONTHS.indexOf(month) + 1).padStart(2, '0')) &&
    (comp === 'Todas' || m.competition === comp));
  const ids = new Set(filtered.map((m) => m.id));
  const fGoals = d.goals.filter((g) => ids.has(g.matchId));
  const fAssists = d.assists.filter((a) => ids.has(a.matchId));

  const stats = {
    jogos: filtered.length,
    min: sum(filtered.map((m) => m.minutes)),
    gols: fGoals.length,
    ass: fAssists.length,
    tit: filtered.filter((m) => m.starter).length,
    res: filtered.filter((m) => !m.starter).length,
  };

  const monthly = useMemo(() => {
    const base = filtered.length ? filtered : [];
    const map = new Map<string, { g: number; a: number; m: number }>();
    base.forEach((m) => {
      const k = m.date.slice(0, 7);
      const e = map.get(k) ?? { g: 0, a: 0, m: 0 };
      e.m += m.minutes;
      e.g += d.goals.filter((x) => x.matchId === m.id).length;
      e.a += d.assists.filter((x) => x.matchId === m.id).length;
      map.set(k, e);
    });
    const keys = [...map.keys()].sort();
    const lab = (k: string) => `${MONTHS[+k.slice(5, 7) - 1]}/${k.slice(2, 4)}`;
    return {
      goals: keys.map((k) => ({ label: lab(k), value: map.get(k)!.g })),
      assists: keys.map((k) => ({ label: lab(k), value: map.get(k)!.a })),
      minutes: keys.map((k) => ({ label: lab(k), value: map.get(k)!.m })),
    };
  }, [filtered, d.goals, d.assists]);

  const save = () => {
    if (parseDate(f.v.date) == null) return setErr('Data inválida (use AAAA-MM-DD).');
    if (!f.v.opponent.trim()) return setErr('Informe o adversário.');
    const st = useStore.getState();
    const matchId = st.upsert('matches', {
      date: f.v.date, opponent: f.v.opponent.trim(), competition: f.v.competition.trim() || 'Amistoso',
      minutes: Math.round(num(f.v.minutes)), starter: f.v.starter, intensity: f.v.intensity,
      scoreFor: Math.round(num(f.v.sf)), scoreAgainst: Math.round(num(f.v.sa)),
    });
    goals.forEach((g) => st.upsert('goals', { matchId, minute: Math.round(num(g.minute)), kind: g.kind, foot: g.foot, assistBy: g.assistBy.trim() }));
    for (let i = 0; i < Math.round(num(f.v.assists)); i++) st.upsert('assists', { matchId, minute: 0, note: '' });
    f.reset(); setGoals([]); setErr(''); setOpen(false);
  };

  const delMatch = (id: string) => confirm('Remover partida', 'Gols e assistências ligados a ela também serão removidos.', () => {
    const st = useStore.getState();
    d.goals.filter((g) => g.matchId === id).forEach((g) => st.remove('goals', g.id));
    d.assists.filter((a) => a.matchId === id).forEach((a) => st.remove('assists', a.id));
    st.remove('matches', id);
  });

  return (
    <Screen>
      <H1>Futebol</H1>
      <Segmented<Tab> value={tab} onChange={setTab}
        options={[{ key: 'resumo', label: 'Resumo' }, { key: 'partidas', label: 'Partidas' }, { key: 'gols', label: 'Gols' }]} />
      <Button title="Registrar partida" onPress={() => setOpen(true)} />

      {tab === 'resumo' && (
        <>
          <Muted style={{ marginBottom: 4 }}>Temporada</Muted>
          <Chips options={seasons} value={season} onChange={setSeason} />
          <Muted style={{ marginBottom: 4 }}>Mês</Muted>
          <Chips options={['Todos', ...MONTHS]} value={month} onChange={setMonth} />
          {comps.length > 2 && (<><Muted style={{ marginBottom: 4 }}>Competição</Muted><Chips options={comps} value={comp} onChange={setComp} /></>)}
          <Row>
            <Stat label="Partidas" value={String(stats.jogos)} />
            <Stat label="Minutos" value={String(stats.min)} sub={stats.jogos ? `${Math.round(stats.min / stats.jogos)} por jogo` : undefined} />
            <Stat label="Gols" value={String(stats.gols)} sub={stats.jogos ? `${(stats.gols / stats.jogos).toFixed(2)} por jogo` : undefined} />
            <Stat label="Assistências" value={String(stats.ass)} />
            <Stat label="Participações em gols" value={String(stats.gols + stats.ass)} />
            <Stat label="Titular / Reserva" value={`${stats.tit} / ${stats.res}`} />
          </Row>
          <Card><BarChart title="Gols por mês" data={monthly.goals} color={colors.blue} /></Card>
          <Card><BarChart title="Assistências por mês" data={monthly.assists} color={colors.ok} /></Card>
          <Card><BarChart title="Minutos jogados por mês" data={monthly.minutes} color={colors.blueSoft} /></Card>
        </>
      )}

      {tab === 'partidas' && (
        <>
          {d.matches.map((m) => {
            const gs = d.goals.filter((g) => g.matchId === m.id).length;
            const as = d.assists.filter((a) => a.matchId === m.id).length;
            return (
              <Card key={m.id}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                  <Text style={{ color: colors.text, fontWeight: '700' }}>vs {m.opponent}  {m.scoreFor}×{m.scoreAgainst}</Text>
                  <Pressable onPress={() => delMatch(m.id)}><Text style={{ color: colors.bad }}>remover</Text></Pressable>
                </View>
                <Muted>{m.date} · {m.competition} · {m.starter ? 'titular' : 'reserva'} · {m.minutes} min · intensidade {m.intensity}/10</Muted>
                <Muted>{gs} gol(s) · {as} assistência(s)</Muted>
              </Card>
            );
          })}
          {!d.matches.length && <Empty text="Nenhuma partida registrada." />}
        </>
      )}

      {tab === 'gols' && (
        <>
          {[...d.goals].sort((a, b) => {
            const da = d.matches.find((m) => m.id === a.matchId)?.date ?? '';
            const db = d.matches.find((m) => m.id === b.matchId)?.date ?? '';
            return db.localeCompare(da) || a.minute - b.minute;
          }).map((g) => {
            const m = d.matches.find((x) => x.id === g.matchId);
            return (
              <Card key={g.id}>
                <Text style={{ color: colors.text, fontWeight: '700' }}>{g.minute}' — {g.kind}</Text>
                <Muted>{m?.date} · vs {m?.opponent} · {m?.competition} · resultado {m?.scoreFor}×{m?.scoreAgainst}</Muted>
                <Muted>Pé: {g.foot}{g.assistBy ? ` · assistência: ${g.assistBy}` : ' · sem assistência'}</Muted>
              </Card>
            );
          })}
          {!d.goals.length && <Empty text="Nenhum gol registrado. Adicione gols ao registrar uma partida." />}
        </>
      )}

      <Sheet visible={open} onClose={() => setOpen(false)} title="Registrar partida">
        <Row style={{ flexWrap: 'nowrap' }}>
          <View style={{ flex: 1 }}><Field label="Data" value={f.v.date} onChangeText={(t) => f.set('date', t)} /></View>
          <View style={{ flex: 1 }}><Field label="Minutos" value={f.v.minutes} keyboard="numeric" onChangeText={(t) => f.set('minutes', t)} /></View>
        </Row>
        <Field label="Adversário" value={f.v.opponent} onChangeText={(t) => f.set('opponent', t)} />
        <Field label="Competição" value={f.v.competition} onChangeText={(t) => f.set('competition', t)} placeholder="Campeonato, amistoso..." />
        <Chips options={['Titular', 'Reserva']} value={f.v.starter ? 'Titular' : 'Reserva'} onChange={(v) => f.set('starter', v === 'Titular')} />
        <Row style={{ flexWrap: 'nowrap' }}>
          <View style={{ flex: 1 }}><Field label="Gols do meu time" value={f.v.sf} keyboard="numeric" onChangeText={(t) => f.set('sf', t)} /></View>
          <View style={{ flex: 1 }}><Field label="Gols do adversário" value={f.v.sa} keyboard="numeric" onChangeText={(t) => f.set('sa', t)} /></View>
          <View style={{ flex: 1 }}><Field label="Minhas assist." value={f.v.assists} keyboard="numeric" onChangeText={(t) => f.set('assists', t)} /></View>
        </Row>
        <Scale label="Intensidade da partida (1–10)" max={10} value={f.v.intensity} onChange={(n) => f.set('intensity', n)} />
        <H2>Meus gols</H2>
        <View style={{ height: 8 }} />
        {goals.map((g, i) => (
          <Card key={i}>
            <Row style={{ flexWrap: 'nowrap' }}>
              <View style={{ flex: 1 }}><Field label="Minuto" value={g.minute} keyboard="numeric" onChangeText={(t) => setGoals(goals.map((x, j) => (j === i ? { ...x, minute: t } : x)))} /></View>
              <View style={{ flex: 2 }}><Field label="Assistência de" value={g.assistBy} onChangeText={(t) => setGoals(goals.map((x, j) => (j === i ? { ...x, assistBy: t } : x)))} placeholder="(opcional)" /></View>
            </Row>
            <Chips options={GOAL_TYPES} value={g.kind} onChange={(k) => setGoals(goals.map((x, j) => (j === i ? { ...x, kind: k } : x)))} />
            <Chips options={FEET} value={g.foot} onChange={(k) => setGoals(goals.map((x, j) => (j === i ? { ...x, foot: k } : x)))} />
            <Button small kind="danger" title="Remover gol" onPress={() => setGoals(goals.filter((_, j) => j !== i))} />
          </Card>
        ))}
        <Button kind="ghost" title="+ Adicionar gol" onPress={() => setGoals([...goals, { minute: '', kind: 'Jogada', foot: 'Direito', assistBy: '' }])} />
        {err ? <Text style={{ color: colors.bad, marginBottom: 8 }}>{err}</Text> : null}
        <Button title="Salvar partida" onPress={save} />
      </Sheet>
    </Screen>
  );
}
