import React, { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { Badge, Button, Card, Empty, Field, H1, H2, Muted, Row, Scale, Screen, Stat, confirm, useForm } from '../ui';
import { BarChart } from '../charts';
import { useData } from '../hooks';
import { useStore } from '../store';
import { colors } from '../theme';
import { DAY, avg, combine, dm, fmtH, hm, num, parseDate, parseTime, startOfDay, sum, ymd } from '../utils';
import { LOW_SLEEP_MIN, SLEEP_TARGET_MIN, sleepMinutes, sessionLoad } from '../engine';
import { rescheduleAll } from '../notifications';

export default function Sleep() {
  const d = useData();
  const [bed, setBed] = useState(d.profile.bedtime);
  const f = useForm({ date: ymd(Date.now()), bed: '23:00', wake: '07:00', q: 3 });
  const s2 = useForm({ date: ymd(Date.now()), time: '01:30', note: '' });
  const [err, setErr] = useState('');
  const [err2, setErr2] = useState('');
  const now = Date.now();

  const last14 = d.sleeps.filter((s) => s.wakeAt > now - 14 * DAY);
  const last7 = d.sleeps.filter((s) => s.wakeAt > now - 7 * DAY);
  const avg7 = last7.length ? avg(last7.map(sleepMinutes)) : null;
  const low = last7.filter((s) => sleepMinutes(s) < LOW_SLEEP_MIN);
  const chart = [...last14].reverse().map((s) => ({ label: dm(s.wakeAt), value: Math.round((sleepMinutes(s) / 60) * 10) / 10 }));

  // atraso médio em relação ao horário ideal
  const target = parseTime(d.profile.bedtime);
  const delays = target ? last7.map((s) => {
    const b = new Date(s.bedAt);
    let m = b.getHours() * 60 + b.getMinutes();
    const t = target.h * 60 + target.m;
    if (m < 12 * 60) m += 1440; // após meia-noite
    const tt = t < 12 * 60 ? t + 1440 : t;
    return m - tt;
  }) : [];
  const avgDelay = delays.length ? Math.round(avg(delays)) : null;

  // sono x desempenho: noite anterior ao treino
  const pairs = d.sessions.map((s) => {
    const sl = d.sleeps.find((x) => x.wakeAt <= s.startedAt && s.startedAt - x.wakeAt < 14 * 3600000);
    return sl ? { sleep: sleepMinutes(sl), rpe: s.rpe ?? 0, vol: sum(s.logs.flatMap((l) => l.sets.map((x) => x.kg * x.reps))) } : null;
  }).filter(Boolean) as { sleep: number; rpe: number; vol: number }[];
  const poor = pairs.filter((p) => p.sleep < LOW_SLEEP_MIN);
  const good = pairs.filter((p) => p.sleep >= 7 * 60);

  const night = d.screenEvents.filter((e) => { const h = new Date(e.at).getHours(); return h >= 0 && h < 5 && e.at > now - 7 * DAY; });

  const saveBed = () => {
    if (!parseTime(bed)) return setErr('Use HH:MM.');
    useStore.getState().setProfile({ bedtime: bed.length === 4 ? '0' + bed : bed });
    setErr(''); void rescheduleAll();
  };
  const saveSleep = () => {
    const wd = parseDate(f.v.date); const b = parseTime(f.v.bed); const w = parseTime(f.v.wake);
    if (wd == null || !b || !w) return setErr('Data (AAAA-MM-DD) ou horários (HH:MM) inválidos.');
    const wakeAt = wd + w.h * 3600000 + w.m * 60000;
    let bedAt = wd + b.h * 3600000 + b.m * 60000;
    if (bedAt >= wakeAt) bedAt -= DAY;
    if (wakeAt - bedAt > 16 * 3600000) return setErr('Duração acima de 16h — confira os horários.');
    useStore.getState().upsert('sleeps', { date: f.v.date, bedAt, wakeAt, quality: f.v.q, source: 'manual' });
    setErr('');
  };
  const saveScreen = () => {
    const at = combine(s2.v.date, s2.v.time);
    if (at == null) return setErr2('Data/hora inválida.');
    useStore.getState().upsert('screenEvents', { at, note: s2.v.note });
    setErr2('');
  };

  return (
    <Screen>
      <H1>Sono</H1>
      <Row>
        <Stat label="Média 7 dias" value={avg7 != null ? fmtH(avg7) : '—'} sub={`Meta ${fmtH(SLEEP_TARGET_MIN)}`} color={avg7 != null && avg7 < LOW_SLEEP_MIN ? colors.warn : undefined} />
        <Stat label="Noites curtas (<6h30)" value={String(low.length)} sub="últimos 7 dias" color={low.length ? colors.warn : undefined} />
      </Row>
      {avgDelay != null && avgDelay > 20 ? (
        <Card style={{ borderColor: colors.warn }}><Text style={{ color: colors.warn, fontWeight: '700' }}>Você está dormindo em média {avgDelay} min depois do horário ideal ({d.profile.bedtime}).</Text></Card>
      ) : null}

      <Card>
        <H2>Horário ideal para dormir</H2>
        <View style={{ height: 8 }} />
        <Field label="HH:MM" value={bed} onChangeText={setBed} />
        <Button title="Salvar e agendar lembrete" onPress={saveBed} />
      </Card>

      <Card><BarChart title="Horas de sono (14 noites)" data={chart} unit=" h" refLine={8} /></Card>

      <Card>
        <H2>Registrar noite</H2>
        <View style={{ height: 8 }} />
        <Row style={{ flexWrap: 'nowrap' }}>
          <View style={{ flex: 1.3 }}><Field label="Acordei em" value={f.v.date} onChangeText={(t) => f.set('date', t)} /></View>
          <View style={{ flex: 1 }}><Field label="Dormi" value={f.v.bed} onChangeText={(t) => f.set('bed', t)} /></View>
          <View style={{ flex: 1 }}><Field label="Acordei" value={f.v.wake} onChangeText={(t) => f.set('wake', t)} /></View>
        </Row>
        <Scale label="Qualidade percebida (1–5)" value={f.v.q} onChange={(n) => f.set('q', n)} />
        {err ? <Text style={{ color: colors.bad, marginBottom: 8 }}>{err}</Text> : null}
        <Button title="Salvar noite" onPress={saveSleep} />
        {d.sleeps.slice(0, 7).map((s) => (
          <View key={s.id} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6 }}>
            <Muted>{dm(s.wakeAt)} · {hm(s.bedAt)} → {hm(s.wakeAt)} · {fmtH(sleepMinutes(s))} · q{s.quality ?? '—'}</Muted>
            <Pressable onPress={() => confirm('Remover registro', '', () => useStore.getState().remove('sleeps', s.id))}><Text style={{ color: colors.bad, fontSize: 12 }}>remover</Text></Pressable>
          </View>
        ))}
        {!d.sleeps.length && <Empty text="Nenhuma noite registrada." />}
      </Card>

      <Card>
        <H2>Sono × desempenho</H2>
        {pairs.length >= 3 ? (
          <>
            <Muted style={{ marginTop: 6 }}>
              Treinos após noite curta (&lt;6h30): {poor.length ? `esforço médio ${avg(poor.map((p) => p.rpe)).toFixed(1)}/10, volume médio ${Math.round(avg(poor.map((p) => p.vol)))} kg` : 'sem amostras'}
            </Muted>
            <Muted>
              Treinos após 7h+ de sono: {good.length ? `esforço médio ${avg(good.map((p) => p.rpe)).toFixed(1)}/10, volume médio ${Math.round(avg(good.map((p) => p.vol)))} kg` : 'sem amostras'}
            </Muted>
            <Muted style={{ marginTop: 6 }}>Comparação descritiva com poucos dados — não indica causa e efeito.</Muted>
          </>
        ) : <Muted style={{ marginTop: 6 }}>Precisa de pelo menos 3 treinos com sono registrado na noite anterior.</Muted>}
      </Card>

      <Card>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><H2>Uso do celular de madrugada</H2><Badge text="INDIRETO" color={colors.warn} /></View>
        <Muted style={{ marginVertical: 8 }}>
          O tempo de tela é só um indicador indireto: o app nunca conclui que você está dormindo porque parou de usar o celular. A leitura automática (Android UsageStats / iOS Screen Time) exige módulos nativos e permissões especiais — ainda não incluída nesta versão; por ora, registre manualmente.
        </Muted>
        {night.length ? (
          <Text style={{ color: colors.warn, marginBottom: 8 }}>⚠ {night.length} uso(s) entre 00h e 05h nos últimos 7 dias — possível atraso no descanso.</Text>
        ) : null}
        <Row style={{ flexWrap: 'nowrap' }}>
          <View style={{ flex: 1.3 }}><Field label="Data" value={s2.v.date} onChangeText={(t) => s2.set('date', t)} /></View>
          <View style={{ flex: 1 }}><Field label="Hora" value={s2.v.time} onChangeText={(t) => s2.set('time', t)} /></View>
        </Row>
        <Field label="Observação" value={s2.v.note} onChangeText={(t) => s2.set('note', t)} />
        {err2 ? <Text style={{ color: colors.bad, marginBottom: 8 }}>{err2}</Text> : null}
        <Button kind="ghost" title="Registrar uso" onPress={saveScreen} />
      </Card>
    </Screen>
  );
}
