import React, { useState } from 'react';
import { Alert, Pressable, Text, View } from 'react-native';
import { Button, Card, Chips, Empty, Field, H1, H2, Muted, Row, Scale, Screen, Sheet, confirm, useForm } from '../ui';
import { BarChart } from '../charts';
import { useData } from '../hooks';
import { useStore } from '../store';
import { colors } from '../theme';
import { CAL_LABEL, CalType, MUSCLE_GROUPS, MuscleGroup } from '../types';
import { DAY, WEEKDAYS, combine, dm, hm, num, startOfWeek, ymd } from '../utils';
import { findConflicts } from '../engine';
import { rescheduleAll } from '../notifications';

const TYPES = Object.keys(CAL_LABEL) as CalType[];

export default function Calendar() {
  const d = useData();
  const [week, setWeek] = useState(startOfWeek(Date.now()));
  const [open, setOpen] = useState(false);
  const f = useForm({ type: 'musculacao' as CalType, title: '', date: ymd(Date.now()), time: '18:00', dur: '60', intensity: 6, notes: '', groups: [] as MuscleGroup[] });
  const [err, setErr] = useState('');

  const days = Array.from({ length: 7 }, (_, i) => week + i * DAY);
  const weekEvents = d.events.filter((e) => e.start >= week && e.start < week + 7 * DAY);
  const conflicts = findConflicts(weekEvents);
  const conflictIds = new Set(conflicts.flat().map((e) => e.id));
  const load = days.map((t, i) => ({
    label: WEEKDAYS[i],
    value: Math.round(weekEvents.filter((e) => e.start >= t && e.start < t + DAY && e.type !== 'descanso' && e.type !== 'recuperacao')
      .reduce((a, e) => a + e.durationMin * e.intensity, 0)),
  }));

  const save = () => {
    const start = combine(f.v.date, f.v.time);
    if (start == null) return setErr('Data (AAAA-MM-DD) ou hora (HH:MM) inválida.');
    const dur = Math.round(num(f.v.dur));
    if (dur <= 0) return setErr('Duração inválida.');
    const title = f.v.title.trim() || CAL_LABEL[f.v.type];
    const overlap = d.events.find((e) => start < e.start + e.durationMin * 60000 && e.start < start + dur * 60000);
    const persist = () => {
      useStore.getState().upsert('events', { type: f.v.type, title, start, durationMin: dur, notes: f.v.notes, intensity: f.v.intensity, groups: f.v.groups });
      f.reset(); setErr(''); setOpen(false); setWeek(startOfWeek(start));
      void rescheduleAll();
    };
    if (overlap) {
      Alert.alert('Conflito de horário', `Sobrepõe "${overlap.title}" (${dm(overlap.start)} ${hm(overlap.start)}). Salvar mesmo assim?`, [
        { text: 'Cancelar', style: 'cancel' }, { text: 'Salvar', onPress: persist },
      ]);
    } else persist();
  };

  return (
    <Screen>
      <H1>Agenda</H1>
      <Row style={{ justifyContent: 'space-between', flexWrap: 'nowrap', marginBottom: 8 }}>
        <Button small kind="ghost" title="‹ Semana" onPress={() => setWeek(week - 7 * DAY)} />
        <Text style={{ color: colors.text, alignSelf: 'center', fontWeight: '700' }}>{dm(week)} – {dm(week + 6 * DAY)}</Text>
        <Button small kind="ghost" title="Semana ›" onPress={() => setWeek(week + 7 * DAY)} />
      </Row>
      <Button title="Novo evento" onPress={() => { f.set('date', ymd(Date.now())); setOpen(true); }} />

      {conflicts.length ? (
        <Card style={{ borderColor: colors.warn }}>
          <H2>⚠ {conflicts.length} conflito(s) nesta semana</H2>
          {conflicts.map(([a, b], i) => <Muted key={i}>{a.title} ({hm(a.start)}) × {b.title} ({hm(b.start)}) — {dm(a.start)}</Muted>)}
        </Card>
      ) : null}

      <Card><BarChart title="Carga planejada por dia (min × intensidade)" data={load} /></Card>

      {days.map((t, i) => {
        const evs = weekEvents.filter((e) => e.start >= t && e.start < t + DAY);
        return (
          <Card key={t}>
            <Text style={{ color: colors.blueSoft, fontWeight: '800' }}>{WEEKDAYS[i]} {dm(t)}</Text>
            {evs.length ? evs.map((e) => (
              <View key={e.id} style={{ paddingVertical: 8, borderBottomColor: colors.border, borderBottomWidth: 1 }}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                  <Text style={{ color: conflictIds.has(e.id) ? colors.warn : colors.text, fontWeight: '700' }}>{hm(e.start)} · {e.title}</Text>
                  <Pressable onPress={() => confirm('Remover evento', e.title, () => { useStore.getState().remove('events', e.id); void rescheduleAll(); })}><Text style={{ color: colors.bad }}>remover</Text></Pressable>
                </View>
                <Muted>{CAL_LABEL[e.type]} · {e.durationMin} min · intensidade {e.intensity}/10{e.groups.length ? ` · ${e.groups.join(', ')}` : ''}</Muted>
                {e.notes ? <Muted>{e.notes}</Muted> : null}
              </View>
            )) : <Muted style={{ marginTop: 4 }}>Livre</Muted>}
          </Card>
        );
      })}

      <Sheet visible={open} onClose={() => setOpen(false)} title="Novo evento">
        <Chips options={TYPES.map((t) => CAL_LABEL[t])} value={CAL_LABEL[f.v.type]}
          onChange={(l) => { const t = TYPES.find((x) => CAL_LABEL[x] === l)!; f.set('type', t); f.set('intensity', t === 'jogo' ? 8 : t === 'descanso' || t === 'recuperacao' ? 2 : 6); }} />
        <Field label="Título" value={f.v.title} onChangeText={(t) => f.set('title', t)} placeholder={CAL_LABEL[f.v.type]} />
        <Row style={{ flexWrap: 'nowrap' }}>
          <View style={{ flex: 1.3 }}><Field label="Data" value={f.v.date} onChangeText={(t) => f.set('date', t)} /></View>
          <View style={{ flex: 1 }}><Field label="Hora" value={f.v.time} onChangeText={(t) => f.set('time', t)} /></View>
          <View style={{ flex: 1 }}><Field label="Min" value={f.v.dur} keyboard="numeric" onChangeText={(t) => f.set('dur', t)} /></View>
        </Row>
        <Scale label="Intensidade esperada (1–10)" max={10} value={f.v.intensity} onChange={(n) => f.set('intensity', n)} />
        {f.v.type === 'musculacao' ? (
          <>
            <Muted style={{ marginBottom: 6 }}>Grupos musculares (usados pela IA)</Muted>
            <Chips multi options={MUSCLE_GROUPS} value={f.v.groups} onChange={(g) => f.set('groups', f.v.groups.includes(g) ? f.v.groups.filter((x) => x !== g) : [...f.v.groups, g])} />
          </>
        ) : null}
        <Field label="Observações" value={f.v.notes} onChangeText={(t) => f.set('notes', t)} multiline />
        {err ? <Text style={{ color: colors.bad, marginBottom: 8 }}>{err}</Text> : null}
        <Button title="Salvar evento" onPress={save} />
      </Sheet>
    </Screen>
  );
}
