import React, { useEffect, useState } from 'react';
import { Alert, Share, Switch, Text, View } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import { Badge, Button, Card, Chips, Field, H1, H2, Muted, Row, Screen, confirm } from '../ui';
import { useData } from '../hooks';
import { useStore } from '../store';
import { colors } from '../theme';
import { cloudConfigured, resetPassword, signIn, signOut, signUp, syncNow } from '../sync';
import { rescheduleAll } from '../notifications';
import { num, parseTime } from '../utils';

const POS = ['Goleiro', 'Zagueiro', 'Lateral', 'Volante', 'Meia', 'Ponta', 'Atacante'];
const NOTIF: { k: keyof ReturnType<typeof useData>['settings']['notif']; l: string }[] = [
  { k: 'train', l: 'Horário de treinar' }, { k: 'match', l: 'Próximo jogo' }, { k: 'sleep', l: 'Horário de dormir' },
  { k: 'rest', l: 'Lembrete de descanso' }, { k: 'weight', l: 'Registro de peso' }, { k: 'stats', l: 'Atualização de estatísticas' },
  { k: 'reco', l: 'Recomendações de treino' }, { k: 'conflict', l: 'Conflitos na agenda' },
];

export default function Profile() {
  const d = useData();
  const st = useStore();
  const p = d.profile;
  const [name, setName] = useState(p.name);
  const [age, setAge] = useState(p.age ? String(p.age) : '');
  const [h, setH] = useState(p.heightCm ? String(p.heightCm) : '');
  const [pos, setPos] = useState(p.position);
  const [goals, setGoals] = useState(p.goals);
  const [hist, setHist] = useState(p.history);
  const [times, setTimes] = useState(p.preferredTimes);
  const [avail, setAvail] = useState(p.weeklyAvailability ? String(p.weeklyAvailability) : '');
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [msg, setMsg] = useState('');
  const [trainTime, setTrainTime] = useState(d.settings.trainTime);
  const [weightTime, setWeightTime] = useState(d.settings.weightTime);

  useEffect(() => { setName(p.name); }, [p.updatedAt]);

  const save = () => {
    st.setProfile({ name: name.trim(), age: age ? Math.round(num(age)) : null, heightCm: h ? num(h) : null, position: pos, goals, history: hist, preferredTimes: times, weeklyAvailability: avail ? Math.round(num(avail)) : null });
    setMsg('Perfil salvo.');
  };

  const applyNotif = async () => {
    if (parseTime(trainTime) && parseTime(weightTime)) st.setSettings({ trainTime, weightTime });
    const n = await rescheduleAll();
    Alert.alert('Lembretes', n ? `${n} lembrete(s) agendado(s).` : 'Permissão de notificações negada ou nada a agendar.');
  };

  const auth = async (mode: 'in' | 'up') => {
    setMsg('Aguarde...');
    const e = mode === 'in' ? await signIn(email.trim(), pw) : await signUp(email.trim(), pw);
    setMsg(e ?? (mode === 'up' ? 'Conta criada. Se pedir, confirme o e-mail e entre.' : 'Conectado.'));
    if (!e) setMsg((await syncNow()));
  };

  const backup = async () => { await Share.share({ message: st.exportAll(), title: 'Backup Athlete Performance' }); };
  const restore = async () => {
    const res = await DocumentPicker.getDocumentAsync({ type: '*/*', copyToCacheDirectory: true });
    if (res.canceled) return;
    const text = await (await fetch(res.assets[0].uri)).text();
    Alert.alert(st.importAll(text) ? 'Backup restaurado' : 'Arquivo inválido');
  };

  return (
    <Screen>
      <H1>Perfil do atleta</H1>
      <Card>
        <Field label="Nome" value={name} onChangeText={setName} />
        <Row style={{ flexWrap: 'nowrap' }}>
          <View style={{ flex: 1 }}><Field label="Idade" value={age} keyboard="numeric" onChangeText={setAge} /></View>
          <View style={{ flex: 1 }}><Field label="Altura (cm)" value={h} keyboard="decimal-pad" onChangeText={setH} /></View>
          <View style={{ flex: 1 }}><Field label="Dias/semana" value={avail} keyboard="numeric" onChangeText={setAvail} /></View>
        </Row>
        <Muted style={{ marginBottom: 6 }}>Posição no futebol</Muted>
        <Chips options={POS} value={pos} onChange={setPos} />
        <Field label="Objetivos esportivos" value={goals} onChangeText={setGoals} multiline />
        <Field label="Histórico de treinamento" value={hist} onChangeText={setHist} multiline />
        <Field label="Preferência de horários" value={times} onChangeText={setTimes} placeholder="Ex.: musculação à noite, jogos aos sábados" />
        <Muted style={{ marginBottom: 8 }}>Peso atual: {d.weights[d.weights.length - 1]?.kg ?? '—'} kg (registre em Academia → Treinar)</Muted>
        <Button title="Salvar perfil" onPress={save} />
        {msg ? <Muted>{msg}</Muted> : null}
      </Card>

      <Card>
        <H2>Notificações</H2>
        <View style={{ height: 8 }} />
        {NOTIF.map((n) => (
          <View key={n.k} style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 4 }}>
            <Text style={{ color: colors.text }}>{n.l}</Text>
            <Switch value={d.settings.notif[n.k]} trackColor={{ true: colors.blue, false: colors.border }}
              onValueChange={(v) => st.setSettings({ notif: { ...d.settings.notif, [n.k]: v } })} />
          </View>
        ))}
        <Row style={{ flexWrap: 'nowrap', marginTop: 8 }}>
          <View style={{ flex: 1 }}><Field label="Hora do treino" value={trainTime} onChangeText={setTrainTime} /></View>
          <View style={{ flex: 1 }}><Field label="Hora da pesagem" value={weightTime} onChangeText={setWeightTime} /></View>
        </Row>
        <Button title="Aplicar lembretes" onPress={applyNotif} />
      </Card>

      <Card>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <H2>Conta e nuvem</H2>
          <Badge text={st.userId ? 'CONECTADO' : cloudConfigured ? 'LOCAL' : 'NUVEM NÃO CONFIGURADA'} color={st.userId ? colors.ok : colors.warn} />
        </View>
        {st.userId ? (
          <>
            <Muted style={{ marginVertical: 8 }}>{st.email} · última sincronização: {d.settings.lastSync ? new Date(d.settings.lastSync).toLocaleString('pt-BR') : 'nunca'} · pendentes: {Object.keys(st.dirty).length}</Muted>
            <Button title="Sincronizar agora" onPress={async () => setMsg(await syncNow())} />
            <Button kind="ghost" title="Sair" onPress={async () => { await signOut(); }} />
          </>
        ) : (
          <>
            <Muted style={{ marginVertical: 8 }}>
              {cloudConfigured ? 'Entre para sincronizar entre dispositivos. Sem login os dados ficam só neste aparelho.' : 'Configure SUPABASE_URL e a chave anônima (veja README) para ativar login e sincronização. Os dados continuam salvos localmente.'}
            </Muted>
            <Field label="E-mail" value={email} onChangeText={setEmail} keyboard="email-address" />
            <Field label="Senha" value={pw} onChangeText={setPw} secure />
            <Button title="Entrar" onPress={() => auth('in')} disabled={!cloudConfigured} />
            <Button kind="ghost" title="Criar conta" onPress={() => auth('up')} disabled={!cloudConfigured} />
            <Button kind="ghost" title="Recuperar senha" onPress={async () => setMsg((await resetPassword(email.trim())) ?? 'E-mail de recuperação enviado.')} disabled={!cloudConfigured} />
          </>
        )}
      </Card>

      <Card>
        <H2>Backup</H2>
        <Muted style={{ marginVertical: 8 }}>Exporta todos os seus dados (JSON) para guardar onde quiser, ou restaura um backup.</Muted>
        <Button kind="ghost" title="Exportar backup" onPress={backup} />
        <Button kind="ghost" title="Restaurar backup" onPress={restore} />
        <Button kind="danger" title="Apagar dados deste aparelho" onPress={() => confirm('Apagar dados locais', 'Isto remove tudo deste aparelho. Dados já sincronizados na nuvem permanecem.', () => st.wipeLocal())} />
      </Card>
    </Screen>
  );
}
