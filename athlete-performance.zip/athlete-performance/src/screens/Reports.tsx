import React, { useMemo, useState } from 'react';
import { Alert } from 'react-native';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { Button, Card, H1, Muted, Screen, Segmented } from '../ui';
import { BarChart, LineChart } from '../charts';
import { useData } from '../hooks';
import { colors } from '../theme';
import { DAY, avg, dm, startOfWeek, sum } from '../utils';
import { computeRecovery, loadBetween, loadPoints, sleepMinutes } from '../engine';

type P = 'sem' | 'mes' | 'tri' | 'ano';
const DAYS: Record<P, number> = { sem: 7, mes: 30, tri: 90, ano: 365 };
const NAME: Record<P, string> = { sem: 'Última semana', mes: 'Último mês', tri: 'Último trimestre', ano: 'Último ano' };

export default function Reports() {
  const d = useData();
  const [p, setP] = useState<P>('mes');
  const now = Date.now();
  const from = now - DAYS[p] * DAY;

  const r = useMemo(() => {
    const sessions = d.sessions.filter((s) => s.startedAt >= from);
    const matches = d.matches.filter((m) => new Date(m.date + 'T12:00:00').getTime() >= from);
    const sleeps = d.sleeps.filter((s) => s.wakeAt >= from);
    const weights = d.weights.filter((w) => w.at >= from);
    const visits = d.visits.filter((v) => v.at >= from && v.confirmed);
    const weeks = Math.max(1, Math.ceil(DAYS[p] / 7));
    const nWeeks = Math.min(weeks, 26);
    const wk0 = startOfWeek(now);
    const wkStarts = Array.from({ length: nWeeks }, (_, i) => wk0 - (nWeeks - 1 - i) * 7 * DAY);
    const pts = loadPoints(d.sessions, d.matches);
    const vol = (a: number, b: number) => sum(d.sessions.filter((s) => s.startedAt >= a && s.startedAt < b).flatMap((s) => s.logs.flatMap((l) => l.sets.map((x) => x.kg * x.reps))));
    const bySeason = new Map<string, number>();
    d.matches.forEach((m) => bySeason.set(m.date.slice(0, 4), (bySeason.get(m.date.slice(0, 4)) ?? 0) + d.goals.filter((g) => g.matchId === m.id).length));
    return {
      sessions, matches, sleeps, weights, visits,
      weight: weights.map((w) => ({ label: dm(w.at), value: w.kg })),
      loadsKg: wkStarts.map((t) => ({ label: dm(t), value: Math.round(vol(t, t + 7 * DAY)) })),
      freq: wkStarts.map((t) => ({ label: dm(t), value: d.sessions.filter((s) => s.startedAt >= t && s.startedAt < t + 7 * DAY).length })),
      trainLoad: wkStarts.map((t) => ({ label: dm(t), value: Math.round(loadBetween(pts, t, t + 7 * DAY)) })),
      goalsSeason: [...bySeason.entries()].sort().map(([k, v]) => ({ label: k, value: v })),
      minutes: wkStarts.map((t) => ({ label: dm(t), value: sum(d.matches.filter((m) => { const x = new Date(m.date + 'T12:00:00').getTime(); return x >= t && x < t + 7 * DAY; }).map((m) => m.minutes)) })),
      sleepAvg: sleeps.length ? avg(sleeps.map(sleepMinutes)) / 60 : null,
      rec: Array.from({ length: Math.min(DAYS[p], 30) }, (_, i) => {
        const t = now - (Math.min(DAYS[p], 30) - 1 - i) * DAY;
        const x = computeRecovery(t, d.sleeps, d.sessions, d.matches, d.feelings);
        return { label: dm(t), value: x.score };
      }).filter((x) => x.value != null) as { label: string; value: number }[],
      goals: d.goals.filter((g) => matches.some((m) => m.id === g.matchId)).length,
      assists: d.assists.filter((a) => matches.some((m) => m.id === a.matchId)).length,
    };
  }, [d, p, from, now]);

  const exportPdf = async () => {
    const bars = (data: { label: string; value: number }[]) => {
      const max = Math.max(1, ...data.map((x) => x.value));
      return data.length ? `<table>${data.map((x) => `<tr><td style="width:60px">${x.label}</td><td><div style="background:#2F6BFF;height:10px;width:${(x.value / max) * 100}%"></div></td><td style="width:60px;text-align:right">${x.value}</td></tr>`).join('')}</table>` : '<p class="m">Sem dados no período.</p>';
    };
    const html = `<html><head><meta charset="utf-8"><style>
      body{font-family:Helvetica,Arial;color:#111;padding:24px} h1{color:#0A1226} h2{color:#2F6BFF;margin-top:22px;border-bottom:1px solid #ccc}
      table{width:100%;border-collapse:collapse;font-size:12px} td{padding:3px} .m{color:#666;font-size:12px}
      .k{display:inline-block;margin:4px 12px 4px 0;padding:8px 12px;border:1px solid #ccc;border-radius:8px}
    </style></head><body>
      <h1>ATHLETE PERFORMANCE — Relatório</h1>
      <p class="m">${d.profile.name || 'Atleta'} · ${NAME[p]} · gerado em ${new Date().toLocaleDateString('pt-BR')}. Indicadores de recuperação são estimativas, não medições clínicas.</p>
      <div><span class="k"><b>${r.sessions.length}</b> treinos</span><span class="k"><b>${r.matches.length}</b> jogos</span><span class="k"><b>${r.goals}</b> gols</span><span class="k"><b>${r.assists}</b> assistências</span><span class="k"><b>${r.sleepAvg != null ? r.sleepAvg.toFixed(1) + ' h' : '—'}</b> sono médio</span><span class="k"><b>${r.visits.length}</b> visitas Wellhub</span></div>
      <h2>Peso corporal (kg)</h2>${bars(r.weight)}
      <h2>Volume de musculação por semana (kg × reps)</h2>${bars(r.loadsKg)}
      <h2>Frequência semanal na academia</h2>${bars(r.freq)}
      <h2>Minutos jogados por semana</h2>${bars(r.minutes)}
      <h2>Carga de treinamento semanal (AU)</h2>${bars(r.trainLoad)}
      <h2>Gols por temporada</h2>${bars(r.goalsSeason)}
      <h2>Recuperação estimada</h2>${bars(r.rec)}
    </body></html>`;
    try {
      const { uri } = await Print.printToFileAsync({ html });
      if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(uri, { mimeType: 'application/pdf', UTI: 'com.adobe.pdf', dialogTitle: 'Relatório' });
      else Alert.alert('PDF gerado', uri);
    } catch (e) {
      Alert.alert('Erro ao gerar PDF', (e as Error).message);
    }
  };

  return (
    <Screen>
      <H1>Relatórios</H1>
      <Segmented<P> value={p} onChange={setP} options={[{ key: 'sem', label: 'Semana' }, { key: 'mes', label: 'Mês' }, { key: 'tri', label: 'Trimestre' }, { key: 'ano', label: 'Ano' }]} />
      <Button title="Exportar PDF" onPress={exportPdf} />
      <Muted style={{ marginBottom: 12 }}>
        {r.sessions.length} treinos · {r.matches.length} jogos · {r.goals} gols · {r.assists} assistências · sono médio {r.sleepAvg != null ? r.sleepAvg.toFixed(1) + ' h' : '—'}
      </Muted>
      <Card><LineChart title="Peso corporal" data={r.weight} unit=" kg" /></Card>
      <Card><BarChart title="Volume de musculação por semana" data={r.loadsKg} unit=" kg" /></Card>
      <Card><BarChart title="Frequência semanal na academia" data={r.freq} color={colors.blueSoft} /></Card>
      <Card><BarChart title="Minutos jogados por semana" data={r.minutes} color={colors.ok} /></Card>
      <Card><BarChart title="Gols por temporada" data={r.goalsSeason} color={colors.ok} /></Card>
      <Card><BarChart title="Carga de treinamento (AU)" data={r.trainLoad} /></Card>
      <Card><LineChart title="Recuperação estimada" data={r.rec} /></Card>
    </Screen>
  );
}
