import React, { useMemo, useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { Button, Card, Chips, Empty, Field, H1, H2, Muted, Row, Scale, Screen, Segmented, Sheet, confirm, useForm } from '../ui';
import { BarChart, LineChart } from '../charts';
import { useAdvice, useData } from '../hooks';
import { useStore } from '../store';
import { colors } from '../theme';
import { ExerciseLog, MUSCLE_GROUPS, MuscleGroup, PlanDay, PlanExercise } from '../types';
import { DAY, combine, dm, e1rm, hm, num, startOfWeek, sum, ymd } from '../utils';
import { suggestLoad, weeklyVolume } from '../engine';

type Tab = 'treinar' | 'planos' | 'exercicios' | 'evolucao';

export default function Gym() {
  const [tab, setTab] = useState<Tab>('treinar');
  return (
    <Screen>
      <H1>Academia</H1>
      <Segmented<Tab>
        value={tab} onChange={setTab}
        options={[{ key: 'treinar', label: 'Treinar' }, { key: 'planos', label: 'Planos' }, { key: 'exercicios', label: 'Exercícios' }, { key: 'evolucao', label: 'Evolução' }]}
      />
      {tab === 'treinar' && <Train />}
      {tab === 'planos' && <Plans />}
      {tab === 'exercicios' && <Exercises />}
      {tab === 'evolucao' && <Evolution />}
    </Screen>
  );
}

/* ---------------- Exercícios ---------------- */
function Exercises() {
  const d = useData();
  const f = useForm({ name: '', group: 'Peito' as MuscleGroup });
  const add = () => {
    if (!f.v.name.trim()) return;
    useStore.getState().upsert('exercises', { name: f.v.name.trim(), group: f.v.group });
    f.set('name', '');
  };
  return (
    <>
      <Card>
        <H2>Cadastrar exercício</H2>
        <View style={{ height: 8 }} />
        <Field label="Nome" value={f.v.name} onChangeText={(t) => f.set('name', t)} placeholder="Ex.: Supino reto" />
        <Chips options={MUSCLE_GROUPS} value={f.v.group} onChange={(g) => f.set('group', g)} />
        <Button title="Adicionar" onPress={add} />
      </Card>
      {MUSCLE_GROUPS.map((g) => {
        const list = d.exercises.filter((e) => e.group === g);
        if (!list.length) return null;
        return (
          <Card key={g}>
            <H2>{g}</H2>
            {list.map((e) => (
              <View key={e.id} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8 }}>
                <Text style={{ color: colors.text }}>{e.name}</Text>
                <Pressable onPress={() => confirm('Remover exercício', e.name, () => useStore.getState().remove('exercises', e.id))}>
                  <Text style={{ color: colors.bad }}>remover</Text>
                </Pressable>
              </View>
            ))}
          </Card>
        );
      })}
      {!d.exercises.length && <Empty text="Cadastre seus exercícios para montar planos e registrar cargas." />}
    </>
  );
}

/* ---------------- Planos ---------------- */
interface DayDraft { name: string; groups: MuscleGroup[]; ex: { id: string; sets: string; reps: string; rest: string; kg: string }[] }
const emptyDay = (): DayDraft => ({ name: '', groups: [], ex: [] });

function Plans() {
  const d = useData();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [days, setDays] = useState<DayDraft[]>([]);
  const [cur, setCur] = useState<DayDraft>(emptyDay());
  const [editId, setEditId] = useState<string | null>(null);

  const addEx = (id: string) =>
    setCur((c) => (c.ex.some((x) => x.id === id) ? c : { ...c, ex: [...c.ex, { id, sets: '3', reps: '10', rest: '90', kg: '0' }] }));
  const addDay = () => {
    if (!cur.name.trim() || !cur.ex.length) return;
    setDays((p) => [...p, { ...cur, groups: cur.groups.length ? cur.groups : [...new Set(cur.ex.map((x) => d.exercises.find((e) => e.id === x.id)!.group))] }]);
    setCur(emptyDay());
  };
  const save = () => {
    if (!name.trim() || !days.length) return;
    const pd: PlanDay[] = days.map((x, i) => ({
      id: `${Date.now()}-${i}`, name: x.name, groups: x.groups,
      exercises: x.ex.map<PlanExercise>((e) => ({ exerciseId: e.id, sets: Math.max(1, Math.round(num(e.sets))), reps: Math.max(1, Math.round(num(e.reps))), restSec: Math.round(num(e.rest)), startKg: num(e.kg) })),
    }));
    useStore.getState().upsert('plans', { id: editId ?? undefined, name: name.trim(), days: pd } as any);
    setOpen(false); setName(''); setDays([]); setCur(emptyDay()); setEditId(null);
  };

  return (
    <>
      <Button title="Novo plano de treino" onPress={() => { if (!d.exercises.length) { confirm('Sem exercícios', 'Cadastre exercícios na aba Exercícios primeiro.', () => {}); return; } setOpen(true); }} />
      {d.plans.map((p) => (
        <Card key={p.id}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <H2>{p.name}</H2>
            <Pressable onPress={() => confirm('Remover plano', p.name, () => useStore.getState().remove('plans', p.id))}><Text style={{ color: colors.bad }}>remover</Text></Pressable>
          </View>
          {p.days.map((day) => (
            <View key={day.id} style={{ marginTop: 10 }}>
              <Text style={{ color: colors.blueSoft, fontWeight: '700' }}>{day.name} <Text style={{ color: colors.dim }}>· {day.groups.join(', ')}</Text></Text>
              {day.exercises.map((e, i) => (
                <Muted key={i}>{d.exercises.find((x) => x.id === e.exerciseId)?.name ?? '—'} — {e.sets}×{e.reps} · {e.restSec}s · {e.startKg} kg</Muted>
              ))}
            </View>
          ))}
        </Card>
      ))}
      {!d.plans.length && <Empty text="Nenhum plano ainda. Divida por grupos musculares (ex.: A Peito/Tríceps, B Costas/Bíceps, C Pernas)." />}

      <Sheet visible={open} onClose={() => setOpen(false)} title="Novo plano">
        <Field label="Nome do plano" value={name} onChangeText={setName} placeholder="Ex.: ABC Hipertrofia" />
        <Muted style={{ marginBottom: 8 }}>Dias adicionados: {days.length ? days.map((x) => x.name).join(' · ') : 'nenhum'}</Muted>
        <Card>
          <H2>Adicionar dia de treino</H2>
          <View style={{ height: 8 }} />
          <Field label="Nome do dia" value={cur.name} onChangeText={(t) => setCur({ ...cur, name: t })} placeholder="A — Peito e Tríceps" />
          <Muted style={{ marginBottom: 6 }}>Escolha os exercícios:</Muted>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 }}>
            {d.exercises.map((e) => (
              <Pressable key={e.id} onPress={() => addEx(e.id)} style={{ borderColor: cur.ex.some((x) => x.id === e.id) ? colors.blue : colors.border, borderWidth: 1, borderRadius: 99, paddingHorizontal: 10, paddingVertical: 6 }}>
                <Text style={{ color: colors.muted, fontSize: 12 }}>{e.name}</Text>
              </Pressable>
            ))}
          </View>
          {cur.ex.map((x, i) => (
            <View key={x.id} style={{ marginBottom: 8 }}>
              <Text style={{ color: colors.text, fontSize: 13, marginBottom: 4 }}>{d.exercises.find((e) => e.id === x.id)?.name}</Text>
              <Row style={{ gap: 6, flexWrap: 'nowrap' }}>
                {(['sets', 'reps', 'rest', 'kg'] as const).map((k) => (
                  <View key={k} style={{ flex: 1 }}>
                    <Field label={{ sets: 'Séries', reps: 'Reps', rest: 'Desc. (s)', kg: 'Kg' }[k]} value={x[k]} keyboard="decimal-pad"
                      onChangeText={(t) => setCur({ ...cur, ex: cur.ex.map((y, j) => (j === i ? { ...y, [k]: t } : y)) })} />
                  </View>
                ))}
              </Row>
            </View>
          ))}
          <Button kind="ghost" title="Adicionar dia ao plano" onPress={addDay} />
        </Card>
        <Button title="Salvar plano" onPress={save} disabled={!name.trim() || !days.length} />
      </Sheet>
    </>
  );
}

/* ---------------- Treinar ---------------- */
interface DraftLog { exerciseId: string; name: string; group: MuscleGroup; sets: { reps: string; kg: string }[]; rest: string; notes: string; hint?: string }

function Train() {
  const d = useData();
  const { rec } = useAdvice();
  const [open, setOpen] = useState(false);
  const [dayName, setDayName] = useState('Treino livre');
  const [logs, setLogs] = useState<DraftLog[]>([]);
  const dt = useForm({ date: ymd(Date.now()), time: hm(Date.now()), dur: '60', rpe: 6 });
  const [err, setErr] = useState('');
  const [wDate, setWDate] = useState('');
  const [kg, setKg] = useState('');

  const startFrom = (day?: PlanDay) => {
    const l: DraftLog[] = [];
    if (day) {
      day.exercises.forEach((pe) => {
        const ex = d.exercises.find((e) => e.id === pe.exerciseId);
        if (!ex) return;
        const sug = suggestLoad(pe, ex.id, ex.group, d.sessions);
        l.push({
          exerciseId: ex.id, name: ex.name, group: ex.group, rest: String(pe.restSec), notes: '',
          sets: Array.from({ length: pe.sets }, () => ({ reps: String(pe.reps), kg: String(sug?.kg ?? pe.startKg) })),
          hint: sug?.reason,
        });
      });
    }
    setLogs(l); setDayName(day?.name ?? 'Treino livre'); dt.setAll({ date: ymd(Date.now()), time: hm(Date.now()), dur: '60', rpe: 6 }); setErr(''); setOpen(true);
  };
  const addExercise = (id: string) => {
    const ex = d.exercises.find((e) => e.id === id)!;
    const sug = suggestLoad(undefined, id, ex.group, d.sessions);
    setLogs((p) => [...p, { exerciseId: id, name: ex.name, group: ex.group, rest: '90', notes: '', sets: [{ reps: '10', kg: String(sug?.kg ?? 0) }], hint: sug?.reason }]);
  };
  const upd = (i: number, fn: (l: DraftLog) => DraftLog) => setLogs((p) => p.map((l, j) => (j === i ? fn(l) : l)));

  const save = () => {
    const at = combine(dt.v.date, dt.v.time);
    if (at == null) return setErr('Data (AAAA-MM-DD) ou hora (HH:MM) inválida.');
    const clean: ExerciseLog[] = logs
      .map((l) => ({
        exerciseId: l.exerciseId, name: l.name, group: l.group, restSec: Math.round(num(l.rest)), notes: l.notes,
        sets: l.sets.map((s) => ({ reps: Math.round(num(s.reps)), kg: num(s.kg) })).filter((s) => s.reps > 0),
      }))
      .filter((l) => l.sets.length);
    if (!clean.length) return setErr('Registre ao menos uma série.');
    const visit = d.visits.find((v) => Math.abs(v.at - at) < 4 * 3600000 && !d.sessions.some((s) => s.wellhubVisitId === v.id));
    useStore.getState().upsert('sessions', { startedAt: at, durationMin: Math.round(num(dt.v.dur)) || 60, planDayName: dayName, rpe: dt.v.rpe, logs: clean, wellhubVisitId: visit?.id } as any);
    setOpen(false);
  };

  const saveWeight = () => {
    const at = wDate ? combine(wDate, '07:00') : Date.now();
    if (at == null || !num(kg)) return;
    useStore.getState().upsert('weights', { at, kg: num(kg) });
    setKg('');
  };

  const suggested = d.plans.flatMap((p) => p.days).find((x) => x.id === rec.suggestedDayId);

  return (
    <>
      {suggested ? (
        <Card style={{ borderColor: colors.blue }}>
          <Muted>Recomendado hoje pela IA</Muted>
          <H2>{suggested.name}</H2>
          <Muted style={{ marginBottom: 8 }}>{rec.detail}</Muted>
          <Button title="Iniciar este treino" onPress={() => startFrom(suggested)} />
        </Card>
      ) : null}
      <Card>
        <H2>Iniciar treino</H2>
        <View style={{ height: 8 }} />
        {d.plans.flatMap((p) => p.days.map((day) => (
          <Button key={day.id} kind="ghost" title={`${p.name} · ${day.name}`} onPress={() => startFrom(day)} />
        )))}
        <Button kind="ghost" title="Treino livre" onPress={() => startFrom()} />
      </Card>

      <Card>
        <H2>Peso corporal</H2>
        <View style={{ height: 8 }} />
        <Row style={{ flexWrap: 'nowrap' }}>
          <View style={{ flex: 1 }}><Field label="Peso (kg)" value={kg} onChangeText={setKg} keyboard="decimal-pad" placeholder="78,5" /></View>
          <View style={{ flex: 1 }}><Field label="Data (opcional)" value={wDate} onChangeText={setWDate} placeholder="AAAA-MM-DD" /></View>
        </Row>
        <Button title="Registrar peso" onPress={saveWeight} />
        {d.weights.slice(-3).reverse().map((w) => <Muted key={w.id}>{dm(w.at)} — {w.kg} kg</Muted>)}
      </Card>

      <H2>Histórico</H2>
      <View style={{ height: 8 }} />
      {d.sessions.slice(0, 15).map((s) => (
        <Card key={s.id}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={{ color: colors.text, fontWeight: '700' }}>{s.planDayName}</Text>
            <Pressable onPress={() => confirm('Remover treino', 'Excluir este registro?', () => useStore.getState().remove('sessions', s.id))}><Text style={{ color: colors.bad }}>remover</Text></Pressable>
          </View>
          <Muted>{dm(s.startedAt)} {hm(s.startedAt)} · {s.durationMin} min · esforço {s.rpe ?? '—'}/10{s.wellhubVisitId ? ' · Wellhub ✓' : ''}</Muted>
          {s.logs.map((l, i) => (
            <Muted key={i}>{l.name}: {l.sets.map((x) => `${x.reps}×${x.kg}kg`).join(' · ')}</Muted>
          ))}
        </Card>
      ))}
      {!d.sessions.length && <Empty text="Nenhum treino registrado." />}

      <Sheet visible={open} onClose={() => setOpen(false)} title={dayName}>
        <Row style={{ flexWrap: 'nowrap' }}>
          <View style={{ flex: 1.3 }}><Field label="Data" value={dt.v.date} onChangeText={(t) => dt.set('date', t)} /></View>
          <View style={{ flex: 1 }}><Field label="Hora" value={dt.v.time} onChangeText={(t) => dt.set('time', t)} /></View>
          <View style={{ flex: 1 }}><Field label="Min" value={dt.v.dur} keyboard="numeric" onChangeText={(t) => dt.set('dur', t)} /></View>
        </Row>
        {logs.map((l, i) => (
          <Card key={l.exerciseId + i}>
            <Text style={{ color: colors.text, fontWeight: '700' }}>{l.name} <Text style={{ color: colors.dim }}>· {l.group}</Text></Text>
            {l.hint ? <Text style={{ color: colors.blueSoft, fontSize: 12, marginBottom: 6 }}>Sugestão: {l.hint}</Text> : null}
            {l.sets.map((s, j) => (
              <Row key={j} style={{ flexWrap: 'nowrap', alignItems: 'flex-end' }}>
                <View style={{ flex: 1 }}><Field label={`Série ${j + 1} · reps`} value={s.reps} keyboard="numeric" onChangeText={(t) => upd(i, (x) => ({ ...x, sets: x.sets.map((y, k) => (k === j ? { ...y, reps: t } : y)) }))} /></View>
                <View style={{ flex: 1 }}><Field label="kg" value={s.kg} keyboard="decimal-pad" onChangeText={(t) => upd(i, (x) => ({ ...x, sets: x.sets.map((y, k) => (k === j ? { ...y, kg: t } : y)) }))} /></View>
              </Row>
            ))}
            <Row style={{ flexWrap: 'nowrap' }}>
              <View style={{ flex: 1 }}><Field label="Descanso (s)" value={l.rest} keyboard="numeric" onChangeText={(t) => upd(i, (x) => ({ ...x, rest: t }))} /></View>
              <View style={{ flex: 2 }}><Field label="Observações" value={l.notes} onChangeText={(t) => upd(i, (x) => ({ ...x, notes: t }))} /></View>
            </Row>
            <Row>
              <Button small kind="ghost" title="+ Série" onPress={() => upd(i, (x) => ({ ...x, sets: [...x.sets, { ...x.sets[x.sets.length - 1] }] }))} />
              <Button small kind="danger" title="Tirar exercício" onPress={() => setLogs((p) => p.filter((_, j) => j !== i))} />
            </Row>
          </Card>
        ))}
        <Muted style={{ marginBottom: 6 }}>Adicionar exercício:</Muted>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 }}>
          {d.exercises.map((e) => (
            <Pressable key={e.id} onPress={() => addExercise(e.id)} style={{ borderColor: colors.border, borderWidth: 1, borderRadius: 99, paddingHorizontal: 10, paddingVertical: 6 }}>
              <Text style={{ color: colors.muted, fontSize: 12 }}>+ {e.name}</Text>
            </Pressable>
          ))}
        </View>
        <Scale label="Percepção de esforço da sessão (1–10)" max={10} value={dt.v.rpe} onChange={(n) => dt.set('rpe', n)} />
        {err ? <Text style={{ color: colors.bad, marginBottom: 8 }}>{err}</Text> : null}
        <Button title="Finalizar e salvar" onPress={save} />
      </Sheet>
    </>
  );
}

/* ---------------- Evolução ---------------- */
function Evolution() {
  const d = useData();
  const [exId, setExId] = useState<string | null>(null);
  const [gran, setGran] = useState<'sem' | 'mes'>('sem');
  const sel = exId ?? d.exercises.find((e) => d.sessions.some((s) => s.logs.some((l) => l.exerciseId === e.id)))?.id ?? null;

  const series = useMemo(() => {
    if (!sel) return { top: [], vol: [] };
    const buckets = new Map<string, { top: number; vol: number; label: string; t: number }>();
    [...d.sessions].reverse().forEach((s) => {
      const l = s.logs.find((x) => x.exerciseId === sel);
      if (!l) return;
      const t = gran === 'sem' ? startOfWeek(s.startedAt) : new Date(new Date(s.startedAt).getFullYear(), new Date(s.startedAt).getMonth(), 1).getTime();
      const key = String(t);
      const b = buckets.get(key) ?? { top: 0, vol: 0, t, label: gran === 'sem' ? dm(t) : `${String(new Date(t).getMonth() + 1).padStart(2, '0')}/${String(new Date(t).getFullYear()).slice(2)}` };
      b.top = Math.max(b.top, ...l.sets.map((x) => x.kg));
      b.vol += sum(l.sets.map((x) => x.kg * x.reps));
      buckets.set(key, b);
    });
    const arr = [...buckets.values()].sort((a, b) => a.t - b.t);
    return { top: arr.map((b) => ({ label: b.label, value: b.top })), vol: arr.map((b) => ({ label: b.label, value: Math.round(b.vol) })) };
  }, [d.sessions, sel, gran]);

  const wk = startOfWeek(Date.now());
  const vol = weeklyVolume(d.sessions, wk, wk + 7 * DAY);
  const volData = Object.entries(vol).map(([label, value]) => ({ label: label.slice(0, 4), value: Math.round(value) }));
  const weights = d.weights.map((w) => ({ label: dm(w.at), value: w.kg }));
  const pr = sel
    ? Math.max(0, ...d.sessions.flatMap((s) => s.logs.filter((l) => l.exerciseId === sel).flatMap((l) => l.sets.map((x) => e1rm(x.kg, x.reps)))))
    : 0;

  return (
    <>
      <Card>
        <H2>Evolução por exercício</H2>
        <View style={{ height: 8 }} />
        <Chips options={d.exercises.map((e) => e.name)} value={d.exercises.find((e) => e.id === sel)?.name ?? null}
          onChange={(n) => setExId(d.exercises.find((e) => e.name === n)?.id ?? null)} />
        <Segmented value={gran} onChange={setGran} options={[{ key: 'sem', label: 'Por semana' }, { key: 'mes', label: 'Por mês' }]} />
        <LineChart title="Maior carga (kg)" data={series.top} unit=" kg" />
        <View style={{ height: 16 }} />
        <BarChart title="Volume (kg × reps)" data={series.vol} />
        {pr > 0 ? <Muted style={{ marginTop: 8 }}>1RM estimado (Epley): {pr.toFixed(1)} kg</Muted> : null}
      </Card>
      <Card><BarChart title="Volume desta semana por grupo muscular" data={volData} color={colors.blueSoft} /></Card>
      <Card><LineChart title="Peso corporal" data={weights} unit=" kg" /></Card>
    </>
  );
}
