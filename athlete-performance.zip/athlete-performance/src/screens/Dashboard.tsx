import React, { useState } from 'react';
import { Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Badge, Button, Card, Chips, Field, H1, H2, Muted, Row, Screen, Scale, Sheet, Stat, useForm, Empty } from '../ui';
import { Ring, BarChart } from '../charts';
import { useAdvice, useData } from '../hooks';
import { colors } from '../theme';
import { CAL_LABEL, MUSCLE_GROUPS, MuscleGroup } from '../types';
import { DAY, ago, dm, fmtH, hm, startOfWeek, sum } from '../utils';
import { loadBetween, loadPoints, sleepMinutes } from '../engine';
import { useStore } from '../store';

export default function Dashboard() {
  const nav = useNavigation<any>();
  const d = useData();
  const { recovery, rec } = useAdvice();
  const [open, setOpen] = useState(false);
  const f = useForm({ fatigue: 2, soreness: 1, groups: [] as MuscleGroup[], note: '' });
  const now = Date.now();

  const nextEvent = d.events.find((e) => e.start > now && (e.type === 'jogo' || e.type === 'futebol' || e.type === 'avaliacao'));
  const nextGame = d.events.find((e) => e.start > now && e.type === 'jogo');
  const todayEvents = d.events.filter((e) => e.start >= new Date().setHours(0, 0, 0, 0) && e.start < new Date().setHours(24, 0, 0, 0));
  const lastWeight = d.weights[d.weights.length - 1];
  const prevWeight = d.weights[d.weights.length - 2];
  const lastSleep = d.sleeps[0];
  const lastTrain = d.sessions[0];
  const pts = loadPoints(d.sessions, d.matches);
  const wk = startOfWeek(now);
  const weekLoad = Math.round(loadBetween(pts, wk, wk + 7 * DAY));
  const weeks = Array.from({ length: 6 }, (_, i) => {
    const s = wk - (5 - i) * 7 * DAY;
    return { label: dm(s), value: Math.round(loadBetween(pts, s, s + 7 * DAY)) };
  });

  const history = [
    ...d.sessions.slice(0, 6).map((s) => ({ t: s.startedAt, txt: `Musculação — ${s.planDayName || 'treino livre'}`, sub: `${s.durationMin} min` })),
    ...d.matches.slice(0, 6).map((m) => ({ t: new Date(m.date + 'T12:00:00').getTime(), txt: `Jogo vs ${m.opponent}`, sub: `${m.minutes} min · ${m.scoreFor}x${m.scoreAgainst}` })),
  ].sort((a, b) => b.t - a.t).slice(0, 6);

  const actionColor = rec.action === 'aumentar' ? colors.ok : rec.action === 'manter' ? colors.blue : rec.action === 'reduzir' ? colors.warn : colors.bad;

  const saveFeeling = () => {
    useStore.getState().upsert('feelings', { at: Date.now(), fatigue: f.v.fatigue, soreness: f.v.soreness, soreGroups: f.v.groups, note: f.v.note });
    f.reset();
    setOpen(false);
  };

  return (
    <Screen>
      <Text style={{ color: colors.blue, fontSize: 11, fontWeight: '800', letterSpacing: 2 }}>ATHLETE PERFORMANCE</Text>
      <H1>{d.profile.name ? `Olá, ${d.profile.name.split(' ')[0]}` : 'Resumo do dia'}</H1>

      <Card style={{ borderColor: actionColor }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Badge text="IA · RECOMENDAÇÃO DE HOJE" color={actionColor} />
          <Badge text="ESTIMATIVA" color={colors.dim} />
        </View>
        <H2>{rec.title}</H2>
        <Muted style={{ marginTop: 4 }}>{rec.detail}</Muted>
        {rec.suggestedDayName ? <Text style={{ color: colors.text, marginTop: 8, fontWeight: '700' }}>Sugestão: {rec.suggestedDayName}</Text> : null}
        {rec.reasons.slice(0, 3).map((r, i) => (
          <Text key={i} style={{ color: colors.muted, fontSize: 12, marginTop: 4 }}>• {r}</Text>
        ))}
        <View style={{ height: 8 }} />
        <Row>
          <Button small title="Ver plano da semana" kind="ghost" onPress={() => nav.navigate('Mais', { screen: 'Plano' })} />
          <Button small title="Como estou hoje" onPress={() => setOpen(true)} />
        </Row>
      </Card>

      <Card>
        <Row style={{ justifyContent: 'space-around' }}>
          <Ring value={recovery.score} label="Recuperação" />
          <Ring value={recovery.fatigue} label="Fadiga" color={recovery.fatigue == null ? colors.dim : recovery.fatigue > 55 ? colors.bad : recovery.fatigue > 35 ? colors.warn : colors.ok} />
        </Row>
        <Muted style={{ textAlign: 'center', marginTop: 8 }}>
          {recovery.score == null ? 'Sem dados suficientes — registre sono, treinos e como se sente.' : `Estimativa (confiança ${recovery.confidence}) — não é uma medição clínica.`}
        </Muted>
      </Card>

      <Row>
        <Stat label="Peso atual" value={lastWeight ? `${lastWeight.kg} kg` : '—'}
          sub={lastWeight && prevWeight ? `${(lastWeight.kg - prevWeight.kg > 0 ? '+' : '')}${(lastWeight.kg - prevWeight.kg).toFixed(1)} kg vs anterior` : 'Registre na Academia'} />
        <Stat label="Sono (última noite)" value={lastSleep ? fmtH(sleepMinutes(lastSleep)) : '—'}
          sub={lastSleep ? undefined : 'Registre em Sono'} color={lastSleep && sleepMinutes(lastSleep) < 390 ? colors.warn : undefined} />
        <Stat label="Último treino" value={lastTrain ? ago(lastTrain.startedAt, now) : '—'} sub={lastTrain?.planDayName} />
        <Stat label="Carga semanal" value={`${weekLoad} AU`} sub="minutos × esforço" />
      </Row>

      <Card>
        <H2>Hoje</H2>
        {todayEvents.length ? todayEvents.map((e) => (
          <Text key={e.id} style={{ color: colors.text, marginTop: 6 }}>{hm(e.start)} · {CAL_LABEL[e.type]} — {e.title}</Text>
        )) : <Muted style={{ marginTop: 4 }}>Nada agendado. Adicione na Agenda.</Muted>}
      </Card>

      <Card>
        <H2>Próximo compromisso</H2>
        {nextEvent ? (
          <>
            <Text style={{ color: colors.text, marginTop: 6, fontWeight: '700' }}>{nextEvent.title}</Text>
            <Muted>{CAL_LABEL[nextEvent.type]} · {dm(nextEvent.start)} às {hm(nextEvent.start)}</Muted>
          </>
        ) : <Muted style={{ marginTop: 4 }}>Nenhum jogo ou treino de futebol agendado.</Muted>}
        {nextGame && nextGame !== nextEvent ? <Muted style={{ marginTop: 6 }}>Próximo jogo: {nextGame.title} em {dm(nextGame.start)}</Muted> : null}
      </Card>

      <Card>
        <BarChart title="Evolução da carga (6 semanas)" data={weeks} unit=" AU" color={colors.blue} />
      </Card>

      <Card>
        <H2>Histórico recente</H2>
        {history.length ? history.map((h, i) => (
          <View key={i} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderBottomColor: colors.border, borderBottomWidth: i < history.length - 1 ? 1 : 0 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: colors.text, fontSize: 14 }}>{h.txt}</Text>
              <Muted>{h.sub}</Muted>
            </View>
            <Muted>{dm(h.t)}</Muted>
          </View>
        )) : <Empty text="Nenhuma atividade registrada ainda." />}
      </Card>

      <Sheet visible={open} onClose={() => setOpen(false)} title="Como você está hoje?">
        <Scale label="Cansaço geral (1 = descansado, 5 = exausto)" value={f.v.fatigue} onChange={(n) => f.set('fatigue', n)} />
        <Scale label="Dor muscular (1 = nenhuma, 5 = forte)" value={f.v.soreness} onChange={(n) => f.set('soreness', n)} />
        {f.v.soreness >= 2 ? (
          <>
            <Muted style={{ marginBottom: 6 }}>Onde?</Muted>
            <Chips multi options={MUSCLE_GROUPS} value={f.v.groups}
              onChange={(g) => f.set('groups', f.v.groups.includes(g) ? f.v.groups.filter((x) => x !== g) : [...f.v.groups, g])} />
          </>
        ) : null}
        <Field label="Observações" value={f.v.note} onChangeText={(t) => f.set('note', t)} multiline />
        <Button title="Salvar" onPress={saveFeeling} />
      </Sheet>
    </Screen>
  );
}
