import React from 'react';
import { Text, View } from 'react-native';
import { Badge, Card, H1, H2, Muted, Row, Screen, Stat } from '../ui';
import { HBar, LineChart, Ring } from '../charts';
import { useAdvice, useData } from '../hooks';
import { colors } from '../theme';
import { DAY, avg, dm, startOfDay } from '../utils';
import { computeRecovery, loadBetween, loadPoints } from '../engine';

export default function Recovery() {
  const d = useData();
  const { recovery, rec } = useAdvice();
  const now = Date.now();
  const pts = loadPoints(d.sessions, d.matches);

  // histórico: recalcula a estimativa para cada um dos últimos 14 dias (só se houver dados)
  const hist = Array.from({ length: 14 }, (_, i) => {
    const t = startOfDay(now - (13 - i) * DAY) + 20 * 3600000;
    const r = computeRecovery(Math.min(t, now), d.sleeps, d.sessions, d.matches, d.feelings);
    return { label: dm(t), value: r.score };
  }).filter((x) => x.value != null) as { label: string; value: number }[];

  const last = d.sessions[0]?.startedAt;
  const lastMatch = d.matches[0] ? new Date(d.matches[0].date + 'T12:00:00').getTime() : undefined;
  const between = d.matches.length >= 2
    ? Math.round((new Date(d.matches[0].date).getTime() - new Date(d.matches[1].date).getTime()) / DAY) : null;
  const freq = d.sessions.filter((s) => s.startedAt > now - 7 * DAY).length + d.matches.filter((m) => new Date(m.date).getTime() > now - 7 * DAY).length;
  const lastF = d.feelings[0];
  const rpes = d.sessions.filter((s) => s.rpe && s.startedAt > now - 14 * DAY).map((s) => s.rpe as number);

  const tips: string[] = [];
  if (recovery.score != null && recovery.score < 60) tips.push('Priorize 8h de sono e hidratação; evite treino máximo hoje.');
  if (lastF && lastF.soreness >= 3) tips.push(`Dor em ${lastF.soreGroups.join(', ') || 'alguns grupos'}: mobilidade, banho morno e treino leve nesses grupos.`);
  if (lastMatch && now - lastMatch < DAY * 1.5) tips.push('Pós-jogo: caminhada leve, alongamento suave e refeição com proteína e carboidrato.');
  if (!tips.length) tips.push('Mantenha sono regular, hidratação e pelo menos um dia de descanso na semana.');

  return (
    <Screen>
      <H1>Recuperação</H1>
      <Card>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}>
          <Badge text="VALORES ESTIMADOS" color={colors.warn} />
          <Badge text={`confiança ${recovery.confidence}`} color={colors.dim} />
        </View>
        <Row style={{ justifyContent: 'space-around' }}>
          <Ring value={recovery.score} label="Recuperação" size={130} />
          <Ring value={recovery.fatigue} label="Fadiga" size={130} color={recovery.fatigue != null && recovery.fatigue > 55 ? colors.bad : colors.warn} />
        </Row>
        <Muted style={{ marginTop: 10 }}>
          Cálculo a partir dos seus próprios registros (sono, carga, relato de cansaço). Não é medição clínica; sem dados, o indicador fica vazio em vez de inventar um valor.
        </Muted>
      </Card>

      <Card>
        <H2>O que compõe a estimativa</H2>
        <View style={{ height: 8 }} />
        {recovery.parts.map((p) => (
          <HBar key={p.label} label={`${p.label} (peso ${Math.round(p.weight * 100)}%)`} value={p.value ?? 0} max={100}
            color={p.value == null ? colors.dim : p.value >= 70 ? colors.ok : p.value >= 45 ? colors.warn : colors.bad} suffix={p.value == null ? ' — sem dados' : ''} />
        ))}
      </Card>

      <Row>
        <Stat label="Atividades (7 dias)" value={String(freq)} sub="treinos + jogos" />
        <Stat label="Entre as 2 últimas partidas" value={between != null ? `${between} dias` : '—'} />
        <Stat label="Esforço médio (14d)" value={rpes.length ? avg(rpes).toFixed(1) : '—'} sub="percepção 1–10" />
        <Stat label="Cansaço relatado" value={lastF ? `${lastF.fatigue}/5` : '—'} sub={lastF ? `dor ${lastF.soreness}/5` : 'Registre no Início'} />
      </Row>

      <Card><LineChart title="Histórico da recuperação estimada" data={hist} /></Card>

      <Card>
        <H2>Recomendações</H2>
        {tips.map((t, i) => <Text key={i} style={{ color: colors.muted, marginTop: 6 }}>• {t}</Text>)}
        <Text style={{ color: colors.text, marginTop: 10, fontWeight: '700' }}>Hoje: {rec.title}</Text>
      </Card>
    </Screen>
  );
}
