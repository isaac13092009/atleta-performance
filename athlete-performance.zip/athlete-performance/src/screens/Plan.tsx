import React from 'react';
import { Text, View } from 'react-native';
import { Badge, Card, H1, H2, Muted, Screen } from '../ui';
import { useData, useAdvice } from '../hooks';
import { colors } from '../theme';
import { DAY, WEEKDAYS, dm, startOfDay } from '../utils';
import { computeRecovery, recommend } from '../engine';

const col = { aumentar: colors.ok, manter: colors.blue, reduzir: colors.warn, descanso: colors.bad } as const;

export default function Plan() {
  const d = useData();
  const { planDays } = useAdvice();
  const today = startOfDay(Date.now());
  const days = Array.from({ length: 7 }, (_, i) => today + i * DAY);

  return (
    <Screen>
      <H1>Plano inteligente</H1>
      <Muted style={{ marginBottom: 12 }}>
        Regras transparentes sobre seus jogos agendados, treinos, grupos musculares, sono e relatos. Hoje usa tudo; dias futuros usam só a agenda e o histórico (sono e cansaço futuros são desconhecidos).
      </Muted>
      {!d.events.length && !d.sessions.length ? (
        <Card><Muted>Adicione jogos e treinos na Agenda para o plano reagir à sua semana.</Muted></Card>
      ) : null}
      {days.map((t, i) => {
        const future = i > 0;
        const recovery = computeRecovery(Date.now(), d.sleeps, d.sessions, d.matches, d.feelings);
        const r = recommend({ date: t + 12 * 3600000, events: d.events, sessions: d.sessions, matches: d.matches, sleeps: d.sleeps, feelings: d.feelings, planDays, recovery, future });
        const evs = d.events.filter((e) => e.start >= t && e.start < t + DAY);
        return (
          <Card key={t} style={{ borderColor: col[r.action] }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <Text style={{ color: colors.blueSoft, fontWeight: '800' }}>{WEEKDAYS[(new Date(t).getDay() + 6) % 7]} {dm(t)}</Text>
              <Badge text={future ? 'PREVISÃO' : 'HOJE'} color={future ? colors.dim : col[r.action]} />
            </View>
            {evs.map((e) => <Muted key={e.id}>📅 {e.title}</Muted>)}
            <H2>{r.title}</H2>
            <Muted>{r.detail}</Muted>
            {r.suggestedDayName ? <Text style={{ color: colors.text, fontWeight: '700', marginTop: 6 }}>Sugestão: {r.suggestedDayName}</Text> : null}
            <Text style={{ color: colors.dim, fontSize: 11, marginTop: 8, fontWeight: '700' }}>POR QUÊ</Text>
            {r.reasons.map((x, j) => <Text key={j} style={{ color: colors.muted, fontSize: 12, marginTop: 3 }}>• {x}</Text>)}
          </Card>
        );
      })}
    </Screen>
  );
}
