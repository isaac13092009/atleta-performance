import React, { useState } from 'react';
import { Alert, Pressable, Text, View } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import { Badge, Button, Card, Empty, Field, H1, H2, Muted, Row, Screen, confirm, useForm } from '../ui';
import { useData } from '../hooks';
import { useStore } from '../store';
import { colors } from '../theme';
import { combine, dm, hm, num, ymd } from '../utils';

export default function Wellhub() {
  const d = useData();
  const f = useForm({ date: ymd(Date.now()), time: hm(Date.now()), gym: '', dur: '' });
  const [err, setErr] = useState('');

  const add = () => {
    const at = combine(f.v.date, f.v.time);
    if (at == null) return setErr('Data (AAAA-MM-DD) ou hora (HH:MM) inválida.');
    useStore.getState().upsert('visits', { at, gym: f.v.gym.trim(), durationMin: f.v.dur ? Math.round(num(f.v.dur)) : null, source: 'manual', confirmed: true });
    f.set('gym', ''); f.set('dur', ''); setErr('');
  };

  const importCsv = async () => {
    try {
      const res = await DocumentPicker.getDocumentAsync({ type: ['text/csv', 'text/comma-separated-values', 'text/plain', '*/*'], copyToCacheDirectory: true });
      if (res.canceled) return;
      const text = await (await fetch(res.assets[0].uri)).text();
      const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
      let n = 0, bad = 0;
      lines.forEach((line, i) => {
        const c = line.split(/[;,]/).map((x) => x.trim().replace(/^"|"$/g, ''));
        if (i === 0 && /data|date/i.test(c[0])) return; // cabeçalho
        // formatos aceitos: AAAA-MM-DD,HH:MM,academia,duração_min  |  DD/MM/AAAA,HH:MM,...
        let date = c[0];
        const br = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(date);
        if (br) date = `${br[3]}-${br[2]}-${br[1]}`;
        const at = combine(date, c[1] ?? '');
        if (at == null) { bad++; return; }
        const exists = d.visits.some((v) => Math.abs(v.at - at) < 60000);
        if (exists) return;
        useStore.getState().upsert('visits', { at, gym: c[2] ?? '', durationMin: c[3] ? Math.round(num(c[3])) : null, source: 'importacao', confirmed: false });
        n++;
      });
      Alert.alert('Importação concluída', `${n} visita(s) importada(s) para confirmação${bad ? `, ${bad} linha(s) ignorada(s)` : ''}.`);
    } catch (e) {
      Alert.alert('Erro ao importar', (e as Error).message);
    }
  };

  const unconfirmed = d.visits.filter((v) => !v.confirmed);

  return (
    <Screen>
      <H1>Wellhub</H1>
      <Card style={{ borderColor: colors.warn }}>
        <Badge text="SOBRE A INTEGRAÇÃO" color={colors.warn} />
        <Muted style={{ marginTop: 8 }}>
          Não há, até onde se sabe, uma API pública do Wellhub para o atleta consultar seus próprios check-ins automaticamente, e este app não usa scraping nem pede suas credenciais. Por isso a integração oficial fica pendente de autorização/parceria com o Wellhub. Enquanto isso, você pode confirmar visitas manualmente ou importar um arquivo CSV (data, hora, academia, duração em minutos). Visitas confirmadas são relacionadas ao treino registrado no mesmo horário (±4h).
        </Muted>
      </Card>

      <Card>
        <H2>Confirmar visita</H2>
        <View style={{ height: 8 }} />
        <Row style={{ flexWrap: 'nowrap' }}>
          <View style={{ flex: 1.3 }}><Field label="Data" value={f.v.date} onChangeText={(t) => f.set('date', t)} /></View>
          <View style={{ flex: 1 }}><Field label="Hora" value={f.v.time} onChangeText={(t) => f.set('time', t)} /></View>
        </Row>
        <Row style={{ flexWrap: 'nowrap' }}>
          <View style={{ flex: 2 }}><Field label="Academia" value={f.v.gym} onChangeText={(t) => f.set('gym', t)} /></View>
          <View style={{ flex: 1 }}><Field label="Min" value={f.v.dur} keyboard="numeric" onChangeText={(t) => f.set('dur', t)} /></View>
        </Row>
        {err ? <Text style={{ color: colors.bad, marginBottom: 8 }}>{err}</Text> : null}
        <Button title="Registrar visita" onPress={add} />
        <Button kind="ghost" title="Importar CSV" onPress={importCsv} />
      </Card>

      {unconfirmed.length ? (
        <Card>
          <H2>Aguardando confirmação</H2>
          {unconfirmed.map((v) => (
            <View key={v.id} style={{ paddingVertical: 8 }}>
              <Muted>{dm(v.at)} {hm(v.at)} · {v.gym || 'academia não informada'}</Muted>
              <Row>
                <Button small title="Confirmar" onPress={() => useStore.getState().upsert('visits', { ...v, confirmed: true })} />
                <Button small kind="danger" title="Descartar" onPress={() => useStore.getState().remove('visits', v.id)} />
              </Row>
            </View>
          ))}
        </Card>
      ) : null}

      <H2>Visitas confirmadas</H2>
      <View style={{ height: 8 }} />
      {d.visits.filter((v) => v.confirmed).map((v) => {
        const linked = d.sessions.find((s) => s.wellhubVisitId === v.id) ?? d.sessions.find((s) => Math.abs(s.startedAt - v.at) < 4 * 3600000);
        return (
          <Card key={v.id}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ color: colors.text, fontWeight: '700' }}>{dm(v.at)} às {hm(v.at)}</Text>
              <Pressable onPress={() => confirm('Remover visita', '', () => useStore.getState().remove('visits', v.id))}><Text style={{ color: colors.bad }}>remover</Text></Pressable>
            </View>
            <Muted>{v.gym || 'Academia não informada'}{v.durationMin ? ` · ${v.durationMin} min` : ''} · origem: {v.source}</Muted>
            <Muted>{linked ? `Treino relacionado: ${linked.planDayName}` : 'Sem treino registrado neste horário'}</Muted>
          </Card>
        );
      })}
      {!d.visits.some((v) => v.confirmed) && <Empty text="Nenhuma visita registrada." />}
    </Screen>
  );
}
