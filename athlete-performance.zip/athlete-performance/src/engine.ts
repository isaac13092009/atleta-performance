import {
  CalEvent, Exercise, Feeling, LEG_GROUPS, Match, MuscleGroup, PlanDay, PlanExercise,
  SleepEntry, WorkoutSession,
} from './types';
import { DAY, avg, clamp, startOfDay, sum, ymd } from './utils';

export const SLEEP_TARGET_MIN = 8 * 60;
export const LOW_SLEEP_MIN = 6 * 60 + 30;

export const sleepMinutes = (s: SleepEntry) => Math.max(0, Math.round((s.wakeAt - s.bedAt) / 60000));

/** Carga em unidades arbitrárias (AU): minutos × esforço (1–10). */
export function sessionLoad(s: WorkoutSession) {
  return s.durationMin * (s.rpe ?? 6);
}
export function matchLoad(m: Match) {
  return m.minutes * m.intensity;
}
export interface LoadPoint { t: number; load: number }
export function loadPoints(sessions: WorkoutSession[], matches: Match[]): LoadPoint[] {
  const pts: LoadPoint[] = [];
  sessions.forEach((s) => pts.push({ t: s.startedAt, load: sessionLoad(s) }));
  matches.forEach((m) => {
    const t = new Date(m.date + 'T12:00:00').getTime();
    pts.push({ t, load: matchLoad(m) });
  });
  return pts.sort((a, b) => a.t - b.t);
}
export function loadBetween(pts: LoadPoint[], from: number, to: number) {
  return sum(pts.filter((p) => p.t >= from && p.t < to).map((p) => p.load));
}

export interface Recovery {
  score: number | null; // 0–100 ou null sem dados
  fatigue: number | null;
  parts: { label: string; value: number | null; weight: number }[];
  confidence: 'sem dados' | 'baixa' | 'média' | 'alta';
  isEstimate: true;
}

export function computeRecovery(
  now: number,
  sleeps: SleepEntry[],
  sessions: WorkoutSession[],
  matches: Match[],
  feelings: Feeling[],
): Recovery {
  // Sono: média das últimas 2 noites vs meta
  const recentSleep = sleeps.filter((s) => s.wakeAt > now - 3 * DAY).sort((a, b) => b.wakeAt - a.wakeAt).slice(0, 2);
  const sleepScore = recentSleep.length
    ? clamp((avg(recentSleep.map(sleepMinutes)) / SLEEP_TARGET_MIN) * 100, 0, 100)
    : null;

  // Carga: aguda (3 dias) vs média diária crônica (28 dias) — quanto maior o excesso, pior
  const pts = loadPoints(sessions, matches);
  const acute = loadBetween(pts, now - 3 * DAY, now + DAY) / 3;
  const chronic = loadBetween(pts, now - 28 * DAY, now - 3 * DAY) / 25;
  let loadScore: number | null = null;
  if (pts.some((p) => p.t > now - 28 * DAY)) {
    if (chronic <= 0) loadScore = acute > 0 ? 55 : 90;
    else loadScore = clamp(100 - Math.max(0, acute / chronic - 0.8) * 70, 5, 100);
  }

  // Percepção (últimas 48h)
  const f = feelings.filter((x) => x.at > now - 2 * DAY).sort((a, b) => b.at - a.at)[0];
  const feelScore = f ? clamp(100 - ((f.fatigue - 1) * 17 + (f.soreness - 1) * 13), 0, 100) : null;

  // Tempo desde a última carga alta
  const last = [...pts].filter((p) => p.t <= now).sort((a, b) => b.t - a.t)[0];
  let restScore: number | null = null;
  if (last) {
    const hours = (now - last.t) / 3600000;
    const need = last.load > 400 ? 48 : 24;
    restScore = clamp((hours / need) * 100, 0, 100);
  }

  const parts = [
    { label: 'Sono (últimas noites)', value: sleepScore, weight: 0.35 },
    { label: 'Carga recente vs. habitual', value: loadScore, weight: 0.25 },
    { label: 'Cansaço/dor relatados', value: feelScore, weight: 0.3 },
    { label: 'Tempo desde a última carga', value: restScore, weight: 0.1 },
  ];
  const have = parts.filter((p) => p.value != null);
  if (!have.length) {
    return { score: null, fatigue: null, parts, confidence: 'sem dados', isEstimate: true };
  }
  const w = sum(have.map((p) => p.weight));
  let score = sum(have.map((p) => (p.value as number) * p.weight)) / w;
  // Relato de cansaço forte limita o teto (nunca recomendar intenso nesse caso)
  if (f && f.fatigue >= 4) score = Math.min(score, 45);
  const confidence = have.length >= 4 ? 'alta' : have.length >= 3 ? 'média' : 'baixa';
  return { score: Math.round(score), fatigue: Math.round(100 - score), parts, confidence, isEstimate: true };
}

export type Action = 'aumentar' | 'manter' | 'reduzir' | 'descanso';
export interface Recommendation {
  action: Action;
  title: string;
  detail: string;
  maxIntensity: number; // 1–10
  avoid: MuscleGroup[];
  suggestedDayId?: string;
  suggestedDayName?: string;
  reasons: string[];
}

export interface PlanInput {
  date: number;
  events: CalEvent[];
  sessions: WorkoutSession[];
  matches: Match[];
  sleeps: SleepEntry[];
  feelings: Feeling[];
  planDays: PlanDay[];
  recovery: Recovery;
  /** Para dias futuros: ignora sinais do momento (sono/cansaço) e usa só o calendário. */
  future?: boolean;
}

function hoursSinceGroup(g: MuscleGroup, sessions: WorkoutSession[], now: number): number {
  let best = Infinity;
  for (const s of sessions) {
    if (s.startedAt > now) continue;
    if (s.logs.some((l) => l.group === g && l.sets.length)) best = Math.min(best, (now - s.startedAt) / 3600000);
  }
  return best;
}

export function recommend(inp: PlanInput): Recommendation {
  const { date, events, sessions, matches, sleeps, feelings, planDays, recovery, future } = inp;
  const day0 = startOfDay(date);
  const reasons: string[] = [];
  const avoid = new Set<MuscleGroup>();
  let cap = 8;
  let action: Action = 'manter';
  let forceRest = false;

  const games = events.filter((e) => e.type === 'jogo');
  const gameToday = games.some((e) => e.start >= day0 && e.start < day0 + DAY);
  const gameTomorrow = games.some((e) => e.start >= day0 + DAY && e.start < day0 + 2 * DAY);
  const gameIn2 = games.some((e) => e.start >= day0 + 2 * DAY && e.start < day0 + 3 * DAY);
  const gameYest = games.find((e) => e.start >= day0 - DAY && e.start < day0);
  const matchYest = matches.find((m) => m.date === ymd(day0 - DAY));
  const prevHard =
    (gameYest && gameYest.intensity >= 7) ||
    (matchYest && (matchYest.intensity >= 7 || matchYest.minutes >= 60));
  const prevAny = !!gameYest || !!matchYest;

  if (gameToday) {
    forceRest = true; cap = 3;
    reasons.push('Há jogo hoje: sem musculação; apenas mobilidade leve e ativação.');
  }
  if (gameTomorrow) {
    cap = Math.min(cap, 6);
    LEG_GROUPS.forEach((g) => avoid.add(g));
    reasons.push('Jogo amanhã: pernas ficam fora e o volume cai para preservar frescor.');
  }
  if (gameIn2) {
    LEG_GROUPS.slice(0, 2).forEach((g) => avoid.add(g));
    cap = Math.min(cap, 7);
    reasons.push('Jogo em 2 dias: evitar treino pesado de pernas (quadríceps/posterior).');
  }
  if (prevAny && prevHard) {
    forceRest = true; cap = Math.min(cap, 3);
    reasons.push('Jogo intenso ontem: dia de recuperação (mobilidade, caminhada, sono).');
  } else if (prevAny) {
    cap = Math.min(cap, 6);
    LEG_GROUPS.forEach((g) => avoid.add(g));
    reasons.push('Houve jogo ontem: musculação adaptada, sem sobrecarregar as pernas.');
  }

  if (!future) {
    if (recovery.score == null) {
      reasons.push('Poucos dados para estimar recuperação: registre sono e como se sente para melhorar a precisão.');
      cap = Math.min(cap, 7);
    } else if (recovery.score < 40) {
      forceRest = true; cap = Math.min(cap, 3);
      reasons.push(`Recuperação estimada baixa (${recovery.score}/100): sem treino intenso.`);
    } else if (recovery.score < 60) {
      cap = Math.min(cap, 6);
      reasons.push(`Recuperação estimada moderada (${recovery.score}/100): reduza carga/volume.`);
    }
    const lastSleep = [...sleeps].sort((a, b) => b.wakeAt - a.wakeAt)[0];
    if (lastSleep && date - lastSleep.wakeAt < 2 * DAY && sleepMinutes(lastSleep) < LOW_SLEEP_MIN) {
      cap = Math.min(cap, 6);
      reasons.push(`Sono curto na última noite (${(sleepMinutes(lastSleep) / 60).toFixed(1)}h): evite treino máximo.`);
    }
    const f = feelings.filter((x) => x.at > date - 2 * DAY).sort((a, b) => b.at - a.at)[0];
    if (f) {
      if (f.fatigue >= 4) {
        forceRest = true; cap = Math.min(cap, 3);
        reasons.push('Cansaço alto relatado: o app não recomenda treino intenso.');
      }
      if (f.soreness >= 3) {
        f.soreGroups.forEach((g) => avoid.add(g));
        if (f.soreGroups.length) reasons.push(`Dor muscular em ${f.soreGroups.join(', ')}: esses grupos ficam de fora.`);
      }
    }
  }

  // Grupos trabalhados há menos de 48h também são evitados
  const trainedRecently: MuscleGroup[] = [];
  (['Peito','Costas','Ombros','Bíceps','Tríceps','Quadríceps','Posterior','Glúteos','Panturrilha','Abdômen'] as MuscleGroup[]).forEach((g) => {
    if (hoursSinceGroup(g, sessions, date) < 48) { avoid.add(g); trainedRecently.push(g); }
  });
  if (trainedRecently.length) reasons.push(`Treinados há menos de 48h: ${trainedRecently.join(', ')}.`);

  // Decisão de ação
  if (forceRest) action = 'descanso';
  else if (cap <= 6) action = 'reduzir';
  else if (!future && recovery.score != null && recovery.score >= 75 && !gameTomorrow && !gameIn2) {
    action = 'aumentar'; cap = 9;
    reasons.push(`Recuperação estimada boa (${recovery.score}/100) e sem jogo próximo: pode progredir a carga.`);
  } else action = 'manter';

  // Escolha do dia do plano
  let suggested: PlanDay | undefined;
  if (action !== 'descanso') {
    const ok = planDays.filter((d) => d.groups.every((g) => !avoid.has(g)));
    const pool = ok.length ? ok : [];
    suggested = pool
      .map((d) => ({ d, h: Math.min(...d.groups.map((g) => hoursSinceGroup(g, sessions, date))) }))
      .sort((a, b) => b.h - a.h)[0]?.d;
    if (!suggested && planDays.length) {
      reasons.push('Nenhum dia do plano é compatível com as restrições: faça versão leve/mobilidade.');
      action = 'reduzir'; cap = Math.min(cap, 5);
    }
  }

  const titles: Record<Action, string> = {
    aumentar: 'Pode aumentar a carga',
    manter: 'Manter a carga',
    reduzir: 'Reduzir a carga',
    descanso: 'Descanso / recuperação ativa',
  };
  const details: Record<Action, string> = {
    aumentar: 'Treino completo com progressão de carga nos principais exercícios.',
    manter: 'Treino normal, sem aumentar carga além do planejado.',
    reduzir: `Treino adaptado: volume ~30% menor, esforço máximo ${cap}/10${avoid.size ? ', evitando ' + [...avoid].join(', ') : ''}.`,
    descanso: 'Sem musculação intensa. Mobilidade, caminhada leve, alimentação e sono.',
  };
  if (!reasons.length) reasons.push('Sem restrições detectadas na agenda e nos dados registrados.');
  reasons.push('Estimativa baseada apenas nos dados registrados — não substitui orientação profissional.');

  return {
    action, title: titles[action], detail: details[action], maxIntensity: cap,
    avoid: [...avoid], suggestedDayId: suggested?.id, suggestedDayName: suggested?.name, reasons,
  };
}

/** Sugestão de próxima carga (progressão automática). */
export function suggestLoad(
  ex: PlanExercise | undefined,
  exerciseId: string,
  group: MuscleGroup,
  sessions: WorkoutSession[],
): { kg: number; reason: string } | null {
  const last = [...sessions]
    .filter((s) => s.logs.some((l) => l.exerciseId === exerciseId && l.sets.length))
    .sort((a, b) => b.startedAt - a.startedAt)[0];
  if (!last) return ex ? { kg: ex.startKg, reason: 'Carga inicial do plano.' } : null;
  const log = last.logs.find((l) => l.exerciseId === exerciseId)!;
  const top = Math.max(...log.sets.map((s) => s.kg));
  const targetReps = ex?.reps ?? 10;
  const hitAll = log.sets.every((s) => s.kg >= top * 0.97 && s.reps >= targetReps);
  const step = LEG_GROUPS.includes(group) ? 5 : 2.5;
  if (hitAll) return { kg: top + step, reason: `Todas as séries com ${targetReps}+ reps na última vez → +${step} kg.` };
  return { kg: top, reason: 'Última vez não completou todas as reps → manter a carga.' };
}

export function weeklyVolume(sessions: WorkoutSession[], from: number, to: number) {
  const byGroup: Record<string, number> = {};
  sessions
    .filter((s) => s.startedAt >= from && s.startedAt < to)
    .forEach((s) => s.logs.forEach((l) => {
      byGroup[l.group] = (byGroup[l.group] ?? 0) + sum(l.sets.map((x) => x.kg * x.reps));
    }));
  return byGroup;
}

export function findConflicts(events: CalEvent[]): [CalEvent, CalEvent][] {
  const res: [CalEvent, CalEvent][] = [];
  const list = [...events].sort((a, b) => a.start - b.start);
  for (let i = 0; i < list.length; i++) {
    for (let j = i + 1; j < list.length; j++) {
      const a = list[i], b = list[j];
      if (b.start >= a.start + a.durationMin * 60000) break;
      res.push([a, b]);
    }
  }
  return res;
}

export const exerciseName = (exs: Exercise[], id: string) => exs.find((e) => e.id === id)?.name ?? '—';
