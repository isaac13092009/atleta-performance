export const DAY = 86400000;
export const uid = () =>
  Date.now().toString(36) + Math.random().toString(36).slice(2, 9);

const p2 = (n: number) => String(n).padStart(2, '0');

export function ymd(d: Date | number): string {
  const x = new Date(d);
  return `${x.getFullYear()}-${p2(x.getMonth() + 1)}-${p2(x.getDate())}`;
}
export function hm(d: Date | number): string {
  const x = new Date(d);
  return `${p2(x.getHours())}:${p2(x.getMinutes())}`;
}
export function dm(d: Date | number): string {
  const x = new Date(d);
  return `${p2(x.getDate())}/${p2(x.getMonth() + 1)}`;
}
export function startOfDay(d: Date | number): number {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x.getTime();
}
export function startOfWeek(d: Date | number): number {
  const x = new Date(startOfDay(d));
  const wd = (x.getDay() + 6) % 7; // segunda = 0
  return x.getTime() - wd * DAY;
}
export const WEEKDAYS = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];
export const weekdayName = (d: Date | number) => WEEKDAYS[(new Date(d).getDay() + 6) % 7];

export function parseDate(s: string): number | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s.trim());
  if (!m) return null;
  const t = new Date(+m[1], +m[2] - 1, +m[3]).getTime();
  return isNaN(t) ? null : t;
}
export function parseTime(s: string): { h: number; m: number } | null {
  const m = /^(\d{1,2}):(\d{2})$/.exec(s.trim());
  if (!m) return null;
  const h = +m[1], mi = +m[2];
  if (h > 23 || mi > 59) return null;
  return { h, m: mi };
}
export function combine(dateStr: string, timeStr: string): number | null {
  const d = parseDate(dateStr);
  const t = parseTime(timeStr);
  if (d == null || !t) return null;
  return d + t.h * 3600000 + t.m * 60000;
}
export const num = (s: string): number => {
  const n = parseFloat(String(s).replace(',', '.'));
  return isNaN(n) ? 0 : n;
};
export const avg = (a: number[]) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0);
export const sum = (a: number[]) => a.reduce((x, y) => x + y, 0);
export const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
export const fmtH = (min: number) => `${Math.floor(min / 60)}h${p2(Math.round(min % 60))}`;
export const e1rm = (kg: number, reps: number) => kg * (1 + reps / 30);

export function ago(ts: number, now = Date.now()): string {
  const h = Math.floor((now - ts) / 3600000);
  if (h < 1) return 'há menos de 1h';
  if (h < 48) return `há ${h}h`;
  return `há ${Math.floor(h / 24)} dias`;
}
