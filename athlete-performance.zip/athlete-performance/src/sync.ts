import 'react-native-url-polyfill/auto';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Constants from 'expo-constants';
import NetInfo from '@react-native-community/netinfo';
import { COLLECTIONS, ColName, useStore } from './store';
import { Base, Profile } from './types';

const extra = (Constants.expoConfig?.extra ?? {}) as { supabaseUrl?: string; supabaseAnonKey?: string };

export const cloudConfigured = !!(extra.supabaseUrl && extra.supabaseAnonKey);

let client: SupabaseClient | null = null;
export function supa(): SupabaseClient | null {
  if (!cloudConfigured) return null;
  if (!client) {
    client = createClient(extra.supabaseUrl!, extra.supabaseAnonKey!, {
      auth: {
        storage: AsyncStorage,
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: false,
      },
    });
  }
  return client;
}

export async function signUp(email: string, password: string): Promise<string | null> {
  const c = supa();
  if (!c) return 'Nuvem não configurada (veja README).';
  const { data, error } = await c.auth.signUp({ email, password });
  if (error) return error.message;
  if (data.user) useStore.getState().setAuth(data.user.id, data.user.email ?? email);
  return null;
}
export async function signIn(email: string, password: string): Promise<string | null> {
  const c = supa();
  if (!c) return 'Nuvem não configurada (veja README).';
  const { data, error } = await c.auth.signInWithPassword({ email, password });
  if (error) return error.message;
  useStore.getState().setAuth(data.user.id, data.user.email ?? email);
  return null;
}
export async function resetPassword(email: string): Promise<string | null> {
  const c = supa();
  if (!c) return 'Nuvem não configurada (veja README).';
  const { error } = await c.auth.resetPasswordForEmail(email);
  return error ? error.message : null;
}
export async function signOut() {
  await supa()?.auth.signOut();
  useStore.getState().setAuth(null, null);
}
export async function restoreSession() {
  const c = supa();
  if (!c) return;
  const { data } = await c.auth.getSession();
  if (data.session) useStore.getState().setAuth(data.session.user.id, data.session.user.email ?? null);
}

let running = false;
/** Sincroniza: envia pendências (last-write-wins por updatedAt) e baixa alterações de outros dispositivos. */
export async function syncNow(): Promise<string> {
  const c = supa();
  const st = useStore.getState();
  if (!c) return 'Nuvem não configurada.';
  if (!st.userId) return 'Faça login para sincronizar.';
  const net = await NetInfo.fetch();
  if (!net.isConnected) return 'Sem conexão — os dados ficam salvos no aparelho.';
  if (running) return 'Sincronização em andamento.';
  running = true;
  try {
    const uidv = st.userId;
    // 1) Envio
    const rows: { user_id: string; collection: string; id: string; data: unknown; updated_at: number; deleted: boolean }[] = [];
    const keys: string[] = [];
    for (const [key] of Object.entries(st.dirty)) {
      const [col, id] = key.split(':');
      if (col === 'profile') continue;
      const rec = (st[col as ColName] as Base[] | undefined)?.find((x) => x.id === id);
      if (!rec) continue;
      rows.push({ user_id: uidv, collection: col, id, data: rec, updated_at: rec.updatedAt, deleted: !!rec.deleted });
      keys.push(key);
    }
    if (rows.length) {
      const { error } = await c.from('records').upsert(rows, { onConflict: 'user_id,collection,id' });
      if (error) throw new Error(error.message);
    }
    if (st.dirty['profile:me']) {
      const { error } = await c.from('athlete_profile').upsert({
        user_id: uidv, data: st.profile, updated_at: st.profile.updatedAt,
      });
      if (error) throw new Error(error.message);
      keys.push('profile:me');
    }
    // 2) Download
    const { data, error } = await c.from('records').select('collection,data,updated_at').eq('user_id', uidv);
    if (error) throw new Error(error.message);
    const byCol: Record<string, Base[]> = {};
    (data ?? []).forEach((r: { collection: string; data: Base }) => {
      (byCol[r.collection] ??= []).push(r.data);
    });
    COLLECTIONS.forEach((col) => byCol[col] && useStore.getState().mergeRemote(col, byCol[col]));
    const { data: pr } = await c.from('athlete_profile').select('data').eq('user_id', uidv).maybeSingle();
    if (pr?.data) useStore.getState().mergeRemoteProfile(pr.data as Profile);

    useStore.getState().clearDirty(keys);
    useStore.getState().setSettings({ lastSync: Date.now() });
    return 'Sincronizado.';
  } catch (e) {
    return `Falha na sincronização: ${(e as Error).message}`;
  } finally {
    running = false;
  }
}

/** Sincroniza automaticamente ao voltar a conexão e a cada alteração (com debounce). */
export function startAutoSync() {
  let timer: ReturnType<typeof setTimeout> | null = null;
  const unsubStore = useStore.subscribe((s, prev) => {
    if (s.userId && s.dirty !== prev.dirty && Object.keys(s.dirty).length) {
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => void syncNow(), 3000);
    }
  });
  const unsubNet = NetInfo.addEventListener((n) => {
    if (n.isConnected && useStore.getState().userId) void syncNow();
  });
  return () => {
    unsubStore();
    unsubNet();
    if (timer) clearTimeout(timer);
  };
}
