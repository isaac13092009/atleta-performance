import React, { useState } from 'react';
import { Text, View, useWindowDimensions } from 'react-native';
import Svg, { Circle, G, Line, Path, Rect, Text as SText } from 'react-native-svg';
import { colors } from './theme';

export interface Pt { label: string; value: number }

const PAD = { l: 34, r: 12, t: 12, b: 24 };

function scale(vals: number[], pad = 0.1) {
  let lo = Math.min(...vals), hi = Math.max(...vals);
  if (lo === hi) { lo = lo - 1; hi = hi + 1; }
  const d = (hi - lo) * pad;
  return { lo: lo - d, hi: hi + d };
}
const nice = (v: number) => (Math.abs(v) >= 100 ? Math.round(v).toString() : (Math.round(v * 10) / 10).toString());

function Frame({ title, selected, unit }: { title?: string; selected: Pt | null; unit?: string }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 }}>
      <Text style={{ color: colors.muted, fontSize: 12 }}>{title}</Text>
      <Text style={{ color: colors.blueSoft, fontSize: 12, fontWeight: '700' }}>
        {selected ? `${selected.label}: ${nice(selected.value)}${unit ?? ''}` : 'toque num ponto'}
      </Text>
    </View>
  );
}

export function LineChart({ data, title, unit, height = 160 }: { data: Pt[]; title?: string; unit?: string; height?: number }) {
  const { width } = useWindowDimensions();
  const w = width - 32 - 34; // padding da tela + card
  const [sel, setSel] = useState<Pt | null>(null);
  if (data.length < 2) {
    return (
      <View>
        <Frame title={title} selected={null} />
        <Text style={{ color: colors.dim, fontSize: 12, paddingVertical: 24, textAlign: 'center' }}>
          {data.length === 1 ? `Único registro: ${nice(data[0].value)}${unit ?? ''}. Registre mais para ver a evolução.` : 'Sem dados no período.'}
        </Text>
      </View>
    );
  }
  const { lo, hi } = scale(data.map((d) => d.value));
  const iw = w - PAD.l - PAD.r, ih = height - PAD.t - PAD.b;
  const x = (i: number) => PAD.l + (i / (data.length - 1)) * iw;
  const y = (v: number) => PAD.t + ih - ((v - lo) / (hi - lo)) * ih;
  const path = data.map((d, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(d.value).toFixed(1)}`).join(' ');
  const ticks = [lo, (lo + hi) / 2, hi];
  const step = Math.max(1, Math.ceil(data.length / 5));
  return (
    <View>
      <Frame title={title} selected={sel} unit={unit} />
      <Svg width={w} height={height}>
        {ticks.map((t, i) => (
          <G key={i}>
            <Line x1={PAD.l} x2={w - PAD.r} y1={y(t)} y2={y(t)} stroke={colors.border} strokeWidth={1} />
            <SText x={PAD.l - 4} y={y(t) + 3} fill={colors.dim} fontSize={9} textAnchor="end">{nice(t)}</SText>
          </G>
        ))}
        <Path d={path} stroke={colors.blue} strokeWidth={2.5} fill="none" />
        {data.map((d, i) => (
          <G key={i}>
            <Circle cx={x(i)} cy={y(d.value)} r={sel === d ? 6 : 3.5} fill={sel === d ? colors.blueSoft : colors.blue} />
            <Circle cx={x(i)} cy={y(d.value)} r={14} fill="transparent" onPress={() => setSel(d)} />
            {i % step === 0 ? (
              <SText x={x(i)} y={height - 6} fill={colors.dim} fontSize={9} textAnchor="middle">{d.label}</SText>
            ) : null}
          </G>
        ))}
      </Svg>
    </View>
  );
}

export function BarChart({
  data, title, unit, height = 160, color = colors.blue, refLine,
}: { data: Pt[]; title?: string; unit?: string; height?: number; color?: string; refLine?: number }) {
  const { width } = useWindowDimensions();
  const w = width - 32 - 34;
  const [sel, setSel] = useState<Pt | null>(null);
  if (!data.length || data.every((d) => d.value === 0)) {
    return (
      <View>
        <Frame title={title} selected={null} />
        <Text style={{ color: colors.dim, fontSize: 12, paddingVertical: 24, textAlign: 'center' }}>Sem dados no período.</Text>
      </View>
    );
  }
  const max = Math.max(...data.map((d) => d.value), refLine ?? 0) * 1.1 || 1;
  const iw = w - PAD.l - PAD.r, ih = height - PAD.t - PAD.b;
  const bw = Math.min(34, (iw / data.length) * 0.7);
  const x = (i: number) => PAD.l + (i + 0.5) * (iw / data.length);
  const y = (v: number) => PAD.t + ih - (v / max) * ih;
  const step = Math.max(1, Math.ceil(data.length / 7));
  return (
    <View>
      <Frame title={title} selected={sel} unit={unit} />
      <Svg width={w} height={height}>
        {[0, max / 2, max].map((t, i) => (
          <G key={i}>
            <Line x1={PAD.l} x2={w - PAD.r} y1={y(t)} y2={y(t)} stroke={colors.border} strokeWidth={1} />
            <SText x={PAD.l - 4} y={y(t) + 3} fill={colors.dim} fontSize={9} textAnchor="end">{nice(t)}</SText>
          </G>
        ))}
        {data.map((d, i) => (
          <G key={i}>
            <Rect
              x={x(i) - bw / 2} y={y(d.value)} width={bw} height={Math.max(1, PAD.t + ih - y(d.value))}
              rx={4} fill={sel === d ? colors.blueSoft : color} onPress={() => setSel(d)}
            />
            {i % step === 0 ? (
              <SText x={x(i)} y={height - 6} fill={colors.dim} fontSize={9} textAnchor="middle">{d.label}</SText>
            ) : null}
          </G>
        ))}
        {refLine != null ? (
          <Line x1={PAD.l} x2={w - PAD.r} y1={y(refLine)} y2={y(refLine)} stroke={colors.warn} strokeDasharray="4,4" strokeWidth={1.5} />
        ) : null}
      </Svg>
    </View>
  );
}

export function Ring({ value, label, sub, size = 120, color }: { value: number | null; label: string; sub?: string; size?: number; color?: string }) {
  const r = size / 2 - 10, c = 2 * Math.PI * r;
  const pct = value == null ? 0 : Math.max(0, Math.min(100, value)) / 100;
  const col = color ?? (value == null ? colors.dim : value >= 70 ? colors.ok : value >= 45 ? colors.warn : colors.bad);
  return (
    <View style={{ alignItems: 'center' }}>
      <View style={{ width: size, height: size }}>
        <Svg width={size} height={size}>
          <Circle cx={size / 2} cy={size / 2} r={r} stroke={colors.border} strokeWidth={9} fill="none" />
          <Circle
            cx={size / 2} cy={size / 2} r={r} stroke={col} strokeWidth={9} fill="none" strokeLinecap="round"
            strokeDasharray={`${c * pct} ${c}`} transform={`rotate(-90 ${size / 2} ${size / 2})`}
          />
        </Svg>
        <View style={{ position: 'absolute', inset: 0, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ color: colors.text, fontSize: 26, fontWeight: '800' }}>{value == null ? '—' : value}</Text>
          <Text style={{ color: colors.muted, fontSize: 10 }}>{sub ?? '/100'}</Text>
        </View>
      </View>
      <Text style={{ color: colors.muted, fontSize: 12, marginTop: 6 }}>{label}</Text>
    </View>
  );
}

export function HBar({ label, value, max, color = colors.blue, suffix = '' }: { label: string; value: number; max: number; color?: string; suffix?: string }) {
  return (
    <View style={{ marginBottom: 8 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Text style={{ color: colors.muted, fontSize: 12 }}>{label}</Text>
        <Text style={{ color: colors.text, fontSize: 12, fontWeight: '700' }}>{nice(value)}{suffix}</Text>
      </View>
      <View style={{ height: 8, backgroundColor: colors.navy, borderRadius: 4, marginTop: 4 }}>
        <View style={{ width: `${max ? Math.min(100, (value / max) * 100) : 0}%`, height: 8, backgroundColor: color, borderRadius: 4 }} />
      </View>
    </View>
  );
}
