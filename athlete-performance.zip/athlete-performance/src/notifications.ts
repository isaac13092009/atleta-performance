import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { useStore, live } from './store';
import { CAL_LABEL } from './types';
import { findConflicts } from './engine';
import { parseTime } from './utils';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

const T = Notifications.SchedulableTriggerInputTypes;

export async function ensurePermission(): Promise<boolean> {
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('default', {
      name: 'Lembretes',
      importance: Notifications.AndroidImportance.DEFAULT,
      lightColor: '#2F6BFF',
    });
  }
  const cur = await Notifications.getPermissionsAsync();
  if (cur.granted) return true;
  const req = await Notifications.requestPermissionsAsync();
  return req.granted;
}

async function daily(title: string, body: string, time: string, minusMin = 0) {
  const t = parseTime(time);
  if (!t) return;
  let total = t.h * 60 + t.m - minusMin;
  if (total < 0) total += 1440;
  await Notifications.scheduleNotificationAsync({
    content: { title, body },
    trigger: { type: T.DAILY, hour: Math.floor(total / 60), minute: total % 60 },
  });
}

/** Recria todos os lembretes a partir das configurações e da agenda. */
export async function rescheduleAll(): Promise<number> {
  const ok = await ensurePermission();
  if (!ok) return 0;
  await Notifications.cancelAllScheduledNotificationsAsync();
  const st = useStore.getState();
  const { notif, trainTime, weightTime, sleepLeadMin } = st.settings;
  let n = 0;
  const now = Date.now();
  const events = live(st.events).filter((e) => e.start > now && e.start < now + 21 * 86400000);

  for (const e of events) {
    const isTrain = e.type === 'musculacao' || e.type === 'futebol' || e.type === 'avaliacao';
    const isGame = e.type === 'jogo';
    const isRest = e.type === 'descanso' || e.type === 'recuperacao';
    if ((isTrain && !notif.train) || (isGame && !notif.match) || (isRest && !notif.rest)) continue;
    const lead = isGame ? 120 : 60;
    const when = e.start - lead * 60000;
    if (when <= now) continue;
    await Notifications.scheduleNotificationAsync({
      content: {
        title: isGame ? 'Próximo jogo' : `${CAL_LABEL[e.type]} em breve`,
        body: `${e.title} — em ${lead >= 60 ? lead / 60 + 'h' : lead + ' min'}`,
      },
      trigger: { type: T.DATE, date: new Date(when) },
    });
    n++;
  }
  if (notif.conflict) {
    const c = findConflicts(events);
    if (c.length) {
      await Notifications.scheduleNotificationAsync({
        content: { title: 'Conflito na agenda', body: `${c.length} conflito(s) de horário. Abra a Agenda para ajustar.` },
        trigger: { type: T.TIME_INTERVAL, seconds: 5, repeats: false },
      });
      n++;
    }
  }
  if (notif.sleep) {
    await daily('Hora de desacelerar', 'Seu horário de dormir está chegando. Deixe o celular de lado.', st.profile.bedtime, sleepLeadMin);
    n++;
  }
  if (notif.weight) { await daily('Registrar peso', 'Pese-se em jejum e registre no app.', weightTime); n++; }
  if (notif.reco) { await daily('Recomendação do dia', 'Veja o treino recomendado para hoje.', trainTime, 120); n++; }
  if (notif.stats) {
    await Notifications.scheduleNotificationAsync({
      content: { title: 'Atualize suas estatísticas', body: 'Registre jogos, gols e sono da semana.' },
      trigger: { type: T.WEEKLY, weekday: 1, hour: 20, minute: 0 },
    });
    n++;
  }
  return n;
}
