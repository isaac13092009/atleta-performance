# ATHLETE PERFORMANCE

Aplicativo multiplataforma para registro de academia, futebol, agenda e análise inicial de rotina esportiva.

## O que já está implementado neste starter

- App React Native com Expo Router e identidade visual escura premium.
- Telas de login/cadastro (Supabase Auth quando configurado).
- Dashboard com estatísticas agregadas.
- Registro e histórico de sessões de academia.
- Registro e histórico de partidas, gols, assistências e minutos.
- Cadastro de compromissos no calendário.
- Primeira análise baseada em regras e nos registros.
- Schema PostgreSQL com Row Level Security.

## Requisitos

- Node.js LTS
- npm
- Expo Go para uma primeira prévia, ou development build para testar recursos nativos
- Projeto Supabase

## Configuração

1. Descompacte o projeto.
2. Instale dependências:

   ```bash
   npm install
   ```

3. Crie um projeto em https://supabase.com.
4. No SQL Editor do Supabase, execute `supabase/schema.sql`.
5. Copie `.env.example` para `.env` e preencha:

   ```env
   EXPO_PUBLIC_SUPABASE_URL=https://SEU-PROJETO.supabase.co
   EXPO_PUBLIC_SUPABASE_ANON_KEY=SUA_CHAVE_PUBLICA_ANON
   ```

   Use somente a chave publicável/anon no aplicativo. Nunca coloque `service_role`, senha do banco ou chave privada no app.

6. Inicie:

   ```bash
   npx expo start
   ```

7. Abra no Expo Go para prévia ou configure um development build para recursos nativos.

## Builds instaláveis

Configure o EAS:

```bash
npm install -g eas-cli
eas login
eas build:configure
```

Android:

```bash
eas build --platform android --profile preview
```

iOS:

```bash
eas build --platform ios
```

Para publicar, configure identificadores, certificados, contas de desenvolvedor e políticas das lojas.

## Estado honesto das integrações

- Wellhub: não está conectado. Depende de acesso oficial e autorização contratual/API. Não inserir senha do Wellhub nem automatizar check-in.
- Health Connect / HealthKit: schema e arquitetura preparados, mas os conectores nativos ainda precisam ser implementados e testados em development builds.
- Sono: a tela ainda não coleta sono automaticamente. Ausência de uso do celular não comprova sono.
- IA: a aba Inteligência usa regras locais transparentes. A integração com modelo de IA deve ser feita por função segura no backend, nunca expondo API key no aplicativo.
- Offline: o starter ainda não possui fila robusta de sincronização offline. Não usar como sistema de produção antes de implementar e testar essa camada.

## Próximas entregas recomendadas

1. Cadastro de exercícios, séries, repetições e progressão de carga.
2. Peso corporal e gráficos de evolução.
3. Edição/exclusão de registros e filtros por período.
4. Calendário visual com edição de eventos.
5. Fila offline e resolução de conflitos.
6. Função de IA segura no Supabase Edge Functions.
7. Integrações nativas Health Connect e HealthKit.
8. Integração Wellhub somente se autorizada.
9. Testes automatizados, acessibilidade, privacidade e publicação.

## Segurança

O schema ativa Row Level Security. Revise e teste as políticas antes de produção. Configure confirmação de e-mail, política de senha, backups e regras de retenção. Dados de saúde são sensíveis e exigem consentimento explícito e controles compatíveis com a LGPD.


## Futebol avançado — atualização

A tela Futebol agora inclui:
- Registro ampliado de partidas: adversário, data/hora, competição, temporada, local, posição, titular/reserva, minutos, gols, assistências, resultado e observações.
- Filtro por temporada.
- Indicadores agregados de partidas, gols, assistências, minutos, titularidades e média de gols por partida.
- Banco de eventos de gol vinculado à partida, com minuto, tipo de gol, pé utilizado, assistência e observações.

**Atualização do banco:** se o projeto Supabase já tiver recebido o schema anterior, execute no SQL Editor o bloco abaixo antes de usar o novo módulo:

```sql
alter table public.football_matches
  add column if not exists competition text,
  add column if not exists season text,
  add column if not exists venue text,
  add column if not exists position text,
  add column if not exists started_as text not null default 'Titular',
  add column if not exists notes text;

create table if not exists public.football_goal_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  match_id uuid not null references public.football_matches(id) on delete cascade,
  minute integer not null check (minute between 0 and 150),
  goal_type text not null default 'Jogada',
  foot text not null default 'Direito',
  assisted_by text,
  notes text,
  created_at timestamptz not null default now()
);

alter table public.football_goal_events enable row level security;
create policy "user owns goal events" on public.football_goal_events
  for all using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create index if not exists football_goal_events_user_match_idx
  on public.football_goal_events(user_id, match_id, minute);
```

Em modo local/demonstração, os registros ficam apenas na memória durante a sessão. Para persistência e sincronização real, configure Supabase.
