export const C = {
  bg: '#07111F',
  panel: '#101D2E',
  panel2: '#15263B',
  blue: '#3987FF',
  blueLight: '#79B5FF',
  text: '#F4F7FB',
  muted: '#91A0B4',
  line: '#23364D',
  green: '#48C78E',
  orange: '#F3AD54',
  red: '#F16D76'
};
