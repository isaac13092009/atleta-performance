import { supabase } from './supabase';
import type { Workout, Match, EventItem, GoalEvent } from './types';

const local = {
  workouts: [] as Workout[],
  matches: [] as Match[],
  events: [] as EventItem[],
  goals: [] as GoalEvent[]
};

export async function loadData() {
  if (!supabase) return local;
  const [w, m, e, g] = await Promise.all([
    supabase.from('workout_sessions').select('*').order('created_at', { ascending: false }).limit(30),
    supabase.from('football_matches').select('*').order('match_date', { ascending: false }).limit(100),
    supabase.from('calendar_events').select('*').order('starts_at', { ascending: true }).limit(30),
    supabase.from('football_goal_events').select('*').order('created_at', { ascending: false }).limit(300)
  ]);
  if (w.error || m.error || e.error || g.error) throw new Error(w.error?.message || m.error?.message || e.error?.message || g.error?.message);
  return { workouts: w.data as Workout[], matches: m.data as Match[], events: e.data as EventItem[], goals: g.data as GoalEvent[] };
}

export async function addWorkout(item: Omit<Workout, 'id'>) {
  if (!supabase) {
    const row = { ...item, id: String(Date.now()) };
    local.workouts.unshift(row);
    return row;
  }
  const { data: userData } = await supabase.auth.getUser();
  const { data, error } = await supabase.from('workout_sessions')
    .insert({ ...item, user_id: userData.user?.id }).select().single();
  if (error) throw error;
  return data as Workout;
}

export async function addMatch(item: Omit<Match, 'id'>) {
  if (!supabase) {
    const row = { ...item, id: String(Date.now()) };
    local.matches.unshift(row);
    return row;
  }
  const { data: userData } = await supabase.auth.getUser();
  const { data, error } = await supabase.from('football_matches')
    .insert({ ...item, user_id: userData.user?.id }).select().single();
  if (error) throw error;
  return data as Match;
}

export async function addEvent(item: Omit<EventItem, 'id'>) {
  if (!supabase) {
    const row = { ...item, id: String(Date.now()) };
    local.events.push(row);
    return row;
  }
  const { data: userData } = await supabase.auth.getUser();
  const { data, error } = await supabase.from('calendar_events')
    .insert({ ...item, user_id: userData.user?.id }).select().single();
  if (error) throw error;
  return data as EventItem;
}


export async function addGoalEvent(item: Omit<GoalEvent, 'id'>) {
  if (!supabase) {
    const row = { ...item, id: String(Date.now()) };
    local.goals.unshift(row);
    return row;
  }
  const { data: userData } = await supabase.auth.getUser();
  const { data, error } = await supabase.from('football_goal_events')
    .insert({ ...item, user_id: userData.user?.id }).select().single();
  if (error) throw error;
  return data as GoalEvent;
}
