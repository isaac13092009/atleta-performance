export type Workout = {
  id: string;
  title: string;
  category: string;
  date: string;
  duration_minutes: number;
  notes?: string;
};
export type Match = {
  id: string;
  opponent: string;
  match_date: string;
  minutes_played: number;
  goals: number;
  assists: number;
  result?: string;
};
export type EventItem = {
  id: string;
  title: string;
  event_type: string;
  starts_at: string;
  notes?: string;
};

export type GoalEvent = {
  id: string;
  match_id: string;
  minute: number;
  goal_type: string;
  foot: string;
  assisted_by?: string;
  notes?: string;
};
