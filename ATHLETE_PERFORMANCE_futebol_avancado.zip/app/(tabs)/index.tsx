import React, { useCallback, useState } from 'react';
import { ScrollView, Text, View, RefreshControl } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { Screen, Heading, Card, Stat } from '../../components/ui';
import { C } from '../../lib/theme';
import { loadData } from '../../lib/data';
import type { Workout, Match, EventItem } from '../../lib/types';

export default function Dashboard() {
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [matches, setMatches] = useState<Match[]>([]);
  const [events, setEvents] = useState<EventItem[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  const refresh = useCallback(async () => {
    setRefreshing(true);
    try {
      const data = await loadData();
      setWorkouts(data.workouts); setMatches(data.matches); setEvents(data.events);
    } catch {}
    setRefreshing(false);
  }, []);
  useFocusEffect(useCallback(() => { refresh(); }, [refresh]));

  const goals = matches.reduce((sum, m) => sum + Number(m.goals || 0), 0);
  const minutes = matches.reduce((sum, m) => sum + Number(m.minutes_played || 0), 0);
  const nextEvent = events.find(e => new Date(e.starts_at).getTime() >= Date.now());

  return <Screen>
    <ScrollView showsVerticalScrollIndicator={false} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor={C.blueLight} />}>
      <View style={{ marginBottom: 20 }}>
        <Text style={{ color: C.blueLight, fontSize: 11, fontWeight: '900', letterSpacing: 3 }}>ATHLETE PERFORMANCE</Text>
        <Heading title="Seu desempenho." subtitle="Visão geral da sua rotina esportiva." />
      </View>
      <Card style={{ backgroundColor: '#112A49', borderColor: '#24528A' }}>
        <Text style={{ color: C.blueLight, fontSize: 11, fontWeight: '800', letterSpacing: 1 }}>FOCO DO DIA</Text>
        <Text style={{ color: C.text, fontSize: 21, fontWeight: '900', marginTop: 8 }}>Consistência vence intensidade.</Text>
        <Text style={{ color: '#B9CDE5', marginTop: 7, lineHeight: 20 }}>Registre seus treinos e partidas para que o sistema consiga analisar sua evolução.</Text>
      </Card>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        <Stat label="Treinos registrados" value={String(workouts.length)} hint="Academia" />
        <Stat label="Gols registrados" value={String(goals)} hint="Futebol" />
        <Stat label="Minutos jogados" value={String(minutes)} hint="Somatório das partidas" />
        <Stat label="Partidas" value={String(matches.length)} hint="Histórico" />
      </View>
      <Card>
        <Text style={{ color: C.text, fontWeight: '800', fontSize: 16 }}>Próximo compromisso</Text>
        <Text style={{ color: C.muted, marginTop: 8 }}>{nextEvent ? nextEvent.title : 'Nenhum compromisso futuro cadastrado.'}</Text>
        {nextEvent && <Text style={{ color: C.blueLight, marginTop: 5 }}>{new Date(nextEvent.starts_at).toLocaleString('pt-BR')}</Text>}
      </Card>
      <Card>
        <Text style={{ color: C.text, fontWeight: '800', fontSize: 16 }}>Últimos registros</Text>
        <Text style={{ color: C.muted, marginTop: 10 }}>{workouts[0] ? `Academia: ${workouts[0].title}` : 'Nenhum treino registrado ainda.'}</Text>
        <Text style={{ color: C.muted, marginTop: 8 }}>{matches[0] ? `Futebol: vs. ${matches[0].opponent}` : 'Nenhuma partida registrada ainda.'}</Text>
      </Card>
      <Text style={{ color: C.muted, textAlign: 'center', fontSize: 11, marginVertical: 15 }}>Dados exibidos conforme os registros disponíveis.</Text>
    </ScrollView>
  </Screen>;
}
