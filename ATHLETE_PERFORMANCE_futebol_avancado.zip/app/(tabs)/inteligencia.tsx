import React, { useCallback, useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { Screen, Heading, Card, Button } from '../../components/ui';
import { C } from '../../lib/theme';
import { loadData } from '../../lib/data';
import type { Workout, Match, EventItem } from '../../lib/types';

export default function Inteligencia() {
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [matches, setMatches] = useState<Match[]>([]);
  const [events, setEvents] = useState<EventItem[]>([]);
  const [analysis, setAnalysis] = useState('Registre treinos, partidas e compromissos para receber uma análise contextual.');
  const refresh = useCallback(async () => {
    try { const d = await loadData(); setWorkouts(d.workouts); setMatches(d.matches); setEvents(d.events); }
    catch { setAnalysis('Não foi possível carregar seus dados. Verifique a conexão e a configuração do banco.'); }
  }, []);
  useFocusEffect(useCallback(() => { refresh(); }, [refresh]));

  function analyze() {
    const upcoming = events.filter(e => new Date(e.starts_at).getTime() > Date.now()).sort((a,b) => +new Date(a.starts_at) - +new Date(b.starts_at))[0];
    const lastMatch = matches[0];
    const lastWorkout = workouts[0];
    let result = 'Ainda há poucos dados para personalizar sua rotina. Continue registrando atividades.';
    if (upcoming) {
      const hours = (new Date(upcoming.starts_at).getTime() - Date.now()) / 3600000;
      if (hours < 30 && /jogo|partida|futebol/i.test(upcoming.event_type + ' ' + upcoming.title)) {
        result = `Você tem "${upcoming.title}" em menos de 30 horas. Evite aumentar a carga de treino sem avaliar como está se sentindo. Priorize descanso e preparação adequada.`;
      } else {
        result = `Seu próximo compromisso é "${upcoming.title}". Organize a carga dos treinos considerando esse horário e sua recuperação.`;
      }
    } else if (lastMatch && lastWorkout) {
      result = `Há registros de academia e futebol. Último treino: ${lastWorkout.title}. Última partida: ${lastMatch.opponent}, com ${lastMatch.minutes_played} minutos. Considere o esforço percebido e a recuperação antes de definir a próxima sessão.`;
    } else if (lastMatch) {
      result = `Sua última partida registrada foi contra ${lastMatch.opponent}, com ${lastMatch.minutes_played} minutos jogados. Registre também sua recuperação para contextualizar o próximo treino.`;
    } else if (lastWorkout) {
      result = `Seu último treino registrado foi "${lastWorkout.title}". Registre partidas e sono para que a análise da rotina fique mais completa.`;
    }
    setAnalysis(result);
  }

  return <Screen>
    <ScrollView showsVerticalScrollIndicator={false}>
      <Heading eyebrow="Centro de decisão" title="Inteligência" subtitle="Análise inicial da sua agenda e dos registros esportivos." />
      <Card style={{ backgroundColor: '#112A49', borderColor: '#24528A' }}>
        <Text style={{ color: C.blueLight, fontWeight: '900', letterSpacing: 1 }}>ATHLETE INTELLIGENCE • V1</Text>
        <Text style={{ color: C.text, fontSize: 19, fontWeight: '900', marginTop: 10 }}>Análise da rotina</Text>
        <Text style={{ color: '#D0DCEC', lineHeight: 22, marginTop: 10 }}>{analysis}</Text>
        <Button title="Analisar meus registros" onPress={analyze} />
      </Card>
      <Card>
        <Text style={{ color: C.text, fontWeight: '800' }}>Dados disponíveis</Text>
        <Text style={{ color: C.muted, marginTop: 8 }}>{workouts.length} treinos • {matches.length} partidas • {events.length} compromissos</Text>
      </Card>
      <Text style={{ color: C.muted, fontSize: 11, lineHeight: 17 }}>Esta versão utiliza regras transparentes baseadas nos registros locais do aplicativo. Não é diagnóstico médico nem substitui avaliação profissional. A integração com um modelo de IA será feita no servidor, sem expor chaves secretas no celular.</Text>
    </ScrollView>
  </Screen>;
}
