import React from 'react';
import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { C } from '../../lib/theme';

const icons: Record<string, keyof typeof Ionicons.glyphMap> = {
  index: 'grid-outline',
  academia: 'barbell-outline',
  futebol: 'football-outline',
  calendario: 'calendar-outline',
  inteligencia: 'sparkles-outline'
};

export default function TabLayout() {
  return <Tabs screenOptions={({ route }) => ({
    headerShown: false,
    tabBarStyle: { backgroundColor: '#0C1929', borderTopColor: C.line, height: 66, paddingTop: 7, paddingBottom: 8 },
    tabBarActiveTintColor: C.blueLight,
    tabBarInactiveTintColor: C.muted,
    tabBarLabelStyle: { fontSize: 10, fontWeight: '700' },
    tabBarIcon: ({ color, size }) => <Ionicons name={icons[route.name] || 'ellipse'} size={size} color={color} />
  })}>
    <Tabs.Screen name="index" options={{ title: 'Início' }} />
    <Tabs.Screen name="academia" options={{ title: 'Academia' }} />
    <Tabs.Screen name="futebol" options={{ title: 'Futebol' }} />
    <Tabs.Screen name="calendario" options={{ title: 'Agenda' }} />
    <Tabs.Screen name="inteligencia" options={{ title: 'IA' }} />
  </Tabs>;
}
