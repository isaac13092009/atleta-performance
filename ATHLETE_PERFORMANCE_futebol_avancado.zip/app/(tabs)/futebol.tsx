import React, { useCallback, useMemo, useState } from 'react';
import { Alert, ScrollView, Text, TouchableOpacity, View } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { Screen, Heading, Card, Field, Label, Button, Stat } from '../../components/ui';
import { C } from '../../lib/theme';
import { addGoalEvent, addMatch, loadData } from '../../lib/data';
import type { GoalEvent, Match } from '../../lib/types';

const inputDate = () => new Date().toISOString().slice(0, 16);

export default function Futebol() {
  const [opponent, setOpponent] = useState('');
  const [matchDate, setMatchDate] = useState(inputDate());
  const [competition, setCompetition] = useState('');
  const [season, setSeason] = useState(String(new Date().getFullYear()));
  const [venue, setVenue] = useState('');
  const [position, setPosition] = useState('Pivô');
  const [startedAs, setStartedAs] = useState('Titular');
  const [minutes, setMinutes] = useState('40');
  const [goals, setGoals] = useState('0');
  const [assists, setAssists] = useState('0');
  const [result, setResult] = useState('');
  const [notes, setNotes] = useState('');

  const [matches, setMatches] = useState<Match[]>([]);
  const [goalEvents, setGoalEvents] = useState<GoalEvent[]>([]);
  const [selectedMatchId, setSelectedMatchId] = useState('');
  const [goalMinute, setGoalMinute] = useState('1');
  const [goalType, setGoalType] = useState('Jogada');
  const [foot, setFoot] = useState('Direito');
  const [assistedBy, setAssistedBy] = useState('');
  const [goalNotes, setGoalNotes] = useState('');
  const [filterSeason, setFilterSeason] = useState('Todas');

  const refresh = useCallback(async () => {
    try {
      const data = await loadData();
      setMatches(data.matches);
      setGoalEvents(data.goals || []);
      if (!selectedMatchId && data.matches.length) setSelectedMatchId(data.matches[0].id);
    } catch (e: any) {
      Alert.alert('Não foi possível carregar', e.message || 'Verifique a conexão e o banco de dados.');
    }
  }, [selectedMatchId]);

  useFocusEffect(useCallback(() => { refresh(); }, [refresh]));

  const seasons = useMemo(() => ['Todas', ...Array.from(new Set(matches.map(m => m.season).filter(Boolean) as string[])).sort().reverse()], [matches]);
  const filteredMatches = useMemo(() => filterSeason === 'Todas' ? matches : matches.filter(m => m.season === filterSeason), [matches, filterSeason]);
  const totals = useMemo(() => filteredMatches.reduce((a, m) => ({
    matches: a.matches + 1,
    goals: a.goals + Number(m.goals || 0),
    assists: a.assists + Number(m.assists || 0),
    minutes: a.minutes + Number(m.minutes_played || 0),
    starters: a.starters + (m.started_as === 'Titular' ? 1 : 0)
  }), { matches: 0, goals: 0, assists: 0, minutes: 0, starters: 0 }), [filteredMatches]);
  const goalsPerMatch = totals.matches ? (totals.goals / totals.matches).toFixed(2) : '0,00';
  const selectedMatch = matches.find(m => m.id === selectedMatchId);
  const selectedGoals = goalEvents.filter(g => g.match_id === selectedMatchId).sort((a,b) => a.minute - b.minute);

  async function saveMatch() {
    if (!opponent.trim()) return Alert.alert('Adversário', 'Informe o adversário ou nome da equipe.');
    const nums = [minutes, goals, assists].map(Number);
    if (nums.some(n => !Number.isInteger(n) || n < 0)) return Alert.alert('Dados inválidos', 'Minutos, gols e assistências devem ser inteiros não negativos.');
    const parsed = new Date(matchDate);
    if (Number.isNaN(parsed.getTime())) return Alert.alert('Data inválida', 'Use AAAA-MM-DDTHH:mm.');
    try {
      const row = await addMatch({
        opponent: opponent.trim(),
        match_date: parsed.toISOString(),
        minutes_played: nums[0],
        goals: nums[1],
        assists: nums[2],
        result,
        competition,
        season,
        venue,
        position,
        started_as: startedAs,
        notes
      } as any);
      setOpponent(''); setGoals('0'); setAssists('0'); setResult(''); setNotes('');
      setSelectedMatchId(row.id);
      await refresh();
      Alert.alert('Partida registrada', 'Agora você pode detalhar cada gol na seção de eventos.');
    } catch (e: any) { Alert.alert('Erro ao salvar', e.message || 'Tente novamente.'); }
  }

  async function saveGoal() {
    const minute = Number(goalMinute);
    if (!selectedMatchId) return Alert.alert('Selecione uma partida', 'Escolha uma partida para vincular o gol.');
    if (!Number.isInteger(minute) || minute < 0 || minute > 150) return Alert.alert('Minuto inválido', 'Informe um minuto entre 0 e 150.');
    try {
      await addGoalEvent({
        match_id: selectedMatchId,
        minute,
        goal_type: goalType,
        foot,
        assisted_by: assistedBy.trim() || undefined,
        notes: goalNotes.trim() || undefined
      });
      setGoalMinute('1'); setAssistedBy(''); setGoalNotes('');
      await refresh();
      Alert.alert('Gol detalhado', 'O evento foi salvo no banco de dados.');
    } catch (e: any) { Alert.alert('Erro ao salvar gol', e.message || 'Confira se executou a atualização do banco de dados.'); }
  }

  const pill = (value: string, current: string, setter: (v: string) => void) => (
    <TouchableOpacity onPress={() => setter(value)} style={{ paddingVertical: 9, paddingHorizontal: 13, borderRadius: 20, marginRight: 7, marginBottom: 7, backgroundColor: current === value ? C.blue : C.panel2, borderWidth: 1, borderColor: current === value ? C.blue : C.line }}>
      <Text style={{ color: C.text, fontWeight: '700', fontSize: 12 }}>{value}</Text>
    </TouchableOpacity>
  );

  return <Screen>
    <ScrollView showsVerticalScrollIndicator={false}>
      <Heading eyebrow="Performance em campo" title="Futebol avançado" subtitle="Partidas, participação, gols e evolução por temporada." />

      <Text style={{ color: C.muted, fontSize: 11, fontWeight: '800', marginBottom: 8 }}>TEMPORADA / FILTRO</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 10 }}>
        {seasons.map(s => pill(s, filterSeason, setFilterSeason))}
      </ScrollView>

      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 9 }}>
        <Stat label="Partidas" value={String(totals.matches)} />
        <Stat label="Gols" value={String(totals.goals)} />
        <Stat label="Assistências" value={String(totals.assists)} />
        <Stat label="Minutos" value={String(totals.minutes)} />
        <Stat label="Titular" value={String(totals.starters)} />
        <Stat label="Gols / jogo" value={goalsPerMatch} />
      </View>

      <Card>
        <Text style={{ color: C.text, fontSize: 17, fontWeight: '900', marginBottom: 14 }}>Registrar partida</Text>
        <Label>Adversário</Label><Field value={opponent} onChangeText={setOpponent} placeholder="Ex.: Equipe Azul" />
        <Label>Data e horário (AAAA-MM-DDTHH:mm)</Label><Field value={matchDate} onChangeText={setMatchDate} />
        <Label>Competição</Label><Field value={competition} onChangeText={setCompetition} placeholder="Ex.: Campeonato municipal" />
        <Label>Temporada</Label><Field value={season} onChangeText={setSeason} placeholder="Ex.: 2026" />
        <Label>Local</Label><Field value={venue} onChangeText={setVenue} placeholder="Casa, fora ou nome do ginásio" />
        <Label>Posição</Label><Field value={position} onChangeText={setPosition} placeholder="Ex.: Pivô" />
        <Label>Condição inicial</Label>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>{['Titular','Reserva'].map(v => pill(v, startedAs, setStartedAs))}</View>
        <Label>Minutos jogados</Label><Field value={minutes} onChangeText={setMinutes} keyboardType="numeric" />
        <View style={{ flexDirection: 'row', gap: 9 }}>
          <View style={{ flex: 1 }}><Label>Gols</Label><Field value={goals} onChangeText={setGoals} keyboardType="numeric" /></View>
          <View style={{ flex: 1 }}><Label>Assistências</Label><Field value={assists} onChangeText={setAssists} keyboardType="numeric" /></View>
        </View>
        <Label>Resultado</Label><Field value={result} onChangeText={setResult} placeholder="Ex.: 3 x 2" />
        <Label>Observações</Label><Field value={notes} onChangeText={setNotes} placeholder="Desempenho, contexto e observações" multiline />
        <Button title="Salvar partida" onPress={saveMatch} />
      </Card>

      <Card>
        <Text style={{ color: C.text, fontSize: 17, fontWeight: '900', marginBottom: 5 }}>Banco de dados de gols</Text>
        <Text style={{ color: C.muted, fontSize: 12, marginBottom: 14 }}>Vincule cada gol a uma partida e registre como aconteceu.</Text>
        <Label>Partida vinculada</Label>
        {matches.length === 0 ? <Text style={{ color: C.muted, marginBottom: 10 }}>Cadastre uma partida primeiro.</Text> :
          <View style={{ marginBottom: 8 }}>
            {matches.slice(0, 8).map(m => (
              <TouchableOpacity key={m.id} onPress={() => setSelectedMatchId(m.id)} style={{ padding: 11, borderRadius: 11, marginBottom: 6, backgroundColor: selectedMatchId === m.id ? '#173A61' : C.panel2, borderWidth: 1, borderColor: selectedMatchId === m.id ? C.blue : C.line }}>
                <Text style={{ color: C.text, fontWeight: '700' }}>vs. {m.opponent} • {new Date(m.match_date).toLocaleDateString('pt-BR')}</Text>
                <Text style={{ color: C.muted, fontSize: 11, marginTop: 3 }}>{m.competition || 'Sem competição cadastrada'}</Text>
              </TouchableOpacity>
            ))}
          </View>
        }
        <Label>Minuto do gol</Label><Field value={goalMinute} onChangeText={setGoalMinute} keyboardType="numeric" />
        <Label>Tipo de gol</Label>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>{['Jogada','Bola parada','Pênalti','Contra-ataque','Falta'].map(v => pill(v, goalType, setGoalType))}</View>
        <Label>Pé utilizado</Label>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>{['Direito','Esquerdo','Cabeceio','Outro'].map(v => pill(v, foot, setFoot))}</View>
        <Label>Assistência de (opcional)</Label><Field value={assistedBy} onChangeText={setAssistedBy} placeholder="Nome do companheiro" />
        <Label>Observações do gol</Label><Field value={goalNotes} onChangeText={setGoalNotes} placeholder="Ex.: finalização após tabela" />
        <Button title="Registrar gol detalhado" onPress={saveGoal} secondary />
        {selectedMatch && <Text style={{ color: C.blueLight, fontSize: 12, marginTop: 12 }}>Partida selecionada: {selectedMatch.opponent}</Text>}
      </Card>

      <Text style={{ color: C.text, fontSize: 18, fontWeight: '900', marginVertical: 10 }}>Histórico de partidas</Text>
      {filteredMatches.length === 0 ? <Text style={{ color: C.muted, marginBottom: 20 }}>Nenhuma partida para este filtro.</Text> : filteredMatches.map(m => (
        <Card key={m.id}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text style={{ color: C.text, fontWeight: '900', fontSize: 16, flex: 1 }}>vs. {m.opponent}</Text>
            <Text style={{ color: C.blueLight, fontWeight: '800' }}>{m.result || '—'}</Text>
          </View>
          <Text style={{ color: C.muted, marginTop: 5 }}>{new Date(m.match_date).toLocaleString('pt-BR')} • {m.competition || 'Amistoso/sem competição'}</Text>
          <Text style={{ color: C.text, marginTop: 8 }}>{m.goals} gols • {m.assists} assistências • {m.minutes_played} minutos</Text>
          <Text style={{ color: C.muted, fontSize: 11, marginTop: 4 }}>{m.started_as || 'Titular'} • {m.position || 'Posição não informada'} • Temporada {m.season || '—'}</Text>
          {!!m.notes && <Text style={{ color: C.muted, marginTop: 7 }}>{m.notes}</Text>}
          <TouchableOpacity onPress={() => setSelectedMatchId(m.id)} style={{ marginTop: 10, alignSelf: 'flex-start' }}>
            <Text style={{ color: C.blueLight, fontWeight: '800' }}>Selecionar para detalhar gols →</Text>
          </TouchableOpacity>
        </Card>
      ))}

      <Text style={{ color: C.text, fontSize: 18, fontWeight: '900', marginVertical: 10 }}>Eventos de gol registrados</Text>
      {selectedGoals.length === 0 ? <Text style={{ color: C.muted, marginBottom: 24 }}>Nenhum gol detalhado nesta partida.</Text> : selectedGoals.map(g => (
        <Card key={g.id}>
          <Text style={{ color: C.text, fontWeight: '900' }}>{g.minute}' • {g.goal_type}</Text>
          <Text style={{ color: C.muted, marginTop: 5 }}>Finalização: {g.foot}{g.assisted_by ? ` • Assistência: ${g.assisted_by}` : ''}</Text>
          {!!g.notes && <Text style={{ color: C.muted, marginTop: 5 }}>{g.notes}</Text>}
        </Card>
      ))}
      <Text style={{ color: C.muted, fontSize: 11, lineHeight: 17, marginVertical: 14 }}>As estatísticas refletem somente os dados registrados. Eventos de gol são um detalhamento separado e não alteram automaticamente o total de gols da partida, evitando contagem duplicada.</Text>
    </ScrollView>
  </Screen>;
}
