import React, { useCallback, useState } from 'react';
import { Alert, ScrollView, Text } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { Screen, Heading, Card, Field, Label, Button } from '../../components/ui';
import { C } from '../../lib/theme';
import { addEvent, loadData } from '../../lib/data';
import type { EventItem } from '../../lib/types';

export default function Calendario() {
  const [title, setTitle] = useState('');
  const [type, setType] = useState('Treino');
  const [date, setDate] = useState(new Date(Date.now() + 3600000).toISOString().slice(0, 16));
  const [notes, setNotes] = useState('');
  const [events, setEvents] = useState<EventItem[]>([]);
  const refresh = useCallback(async () => { try { setEvents((await loadData()).events); } catch {} }, []);
  useFocusEffect(useCallback(() => { refresh(); }, [refresh]));

  async function save() {
    if (!title.trim()) return Alert.alert('Título', 'Informe o nome do compromisso.');
    const parsed = new Date(date);
    if (Number.isNaN(parsed.getTime())) return Alert.alert('Data inválida', 'Use o formato AAAA-MM-DDTHH:mm.');
    try {
      await addEvent({ title: title.trim(), event_type: type, starts_at: parsed.toISOString(), notes });
      setTitle(''); setNotes(''); await refresh();
      Alert.alert('Compromisso agendado', 'O evento foi salvo na agenda.');
    } catch (e: any) { Alert.alert('Erro ao salvar', e.message || 'Tente novamente.'); }
  }

  return <Screen>
    <ScrollView showsVerticalScrollIndicator={false}>
      <Heading eyebrow="Planejamento" title="Calendário" subtitle="Organize treinos, jogos e recuperação." />
      <Card>
        <Text style={{ color: C.text, fontWeight: '900', fontSize: 17, marginBottom: 14 }}>Novo compromisso</Text>
        <Label>Nome</Label><Field value={title} onChangeText={setTitle} placeholder="Ex.: Jogo do campeonato" />
        <Label>Tipo</Label><Field value={type} onChangeText={setType} placeholder="Treino, Jogo, Descanso..." />
        <Label>Data e horário</Label><Field value={date} onChangeText={setDate} placeholder="2026-11-25T18:00" />
        <Label>Observações</Label><Field value={notes} onChangeText={setNotes} placeholder="Local, adversário ou detalhes" />
        <Button title="Agendar compromisso" onPress={save} />
      </Card>
      <Text style={{ color: C.text, fontWeight: '900', fontSize: 18, marginVertical: 10 }}>Agenda registrada</Text>
      {events.length === 0 ? <Text style={{ color: C.muted }}>Seus compromissos aparecerão aqui.</Text> : events.map(e =>
        <Card key={e.id}>
          <Text style={{ color: C.text, fontWeight: '800', fontSize: 16 }}>{e.title}</Text>
          <Text style={{ color: C.blueLight, marginTop: 5 }}>{e.event_type}</Text>
          <Text style={{ color: C.muted, marginTop: 5 }}>{new Date(e.starts_at).toLocaleString('pt-BR')}</Text>
          {!!e.notes && <Text style={{ color: C.text, marginTop: 7 }}>{e.notes}</Text>}
        </Card>
      )}
    </ScrollView>
  </Screen>;
}
