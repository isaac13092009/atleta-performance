import React, { useCallback, useState } from 'react';
import { Alert, ScrollView, Text, View } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { Screen, Heading, Card, Field, Label, Button } from '../../components/ui';
import { C } from '../../lib/theme';
import { addWorkout, loadData } from '../../lib/data';
import type { Workout } from '../../lib/types';

export default function Academia() {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Musculação');
  const [duration, setDuration] = useState('60');
  const [notes, setNotes] = useState('');
  const [items, setItems] = useState<Workout[]>([]);
  const refresh = useCallback(async () => { try { setItems((await loadData()).workouts); } catch {} }, []);
  useFocusEffect(useCallback(() => { refresh(); }, [refresh]));

  async function save() {
    if (!title.trim()) return Alert.alert('Informe o treino', 'Digite o nome da sessão.');
    const minutes = Number(duration);
    if (!Number.isFinite(minutes) || minutes < 1) return Alert.alert('Duração inválida', 'Informe a duração em minutos.');
    try {
      await addWorkout({ title: title.trim(), category, date: new Date().toISOString(), duration_minutes: minutes, notes });
      setTitle(''); setNotes(''); await refresh();
      Alert.alert('Treino registrado', 'Sua sessão foi adicionada ao histórico.');
    } catch (e: any) { Alert.alert('Erro ao salvar', e.message || 'Tente novamente.'); }
  }

  return <Screen>
    <ScrollView showsVerticalScrollIndicator={false}>
      <Heading eyebrow="Treinamento de força" title="Academia" subtitle="Registre suas sessões e acompanhe a consistência." />
      <Card>
        <Text style={{ color: C.text, fontWeight: '900', fontSize: 17, marginBottom: 14 }}>Nova sessão</Text>
        <Label>Nome do treino</Label><Field value={title} onChangeText={setTitle} placeholder="Ex.: Superiores A" />
        <Label>Categoria</Label><Field value={category} onChangeText={setCategory} placeholder="Musculação, mobilidade..." />
        <Label>Duração (minutos)</Label><Field value={duration} onChangeText={setDuration} keyboardType="numeric" />
        <Label>Observações</Label><Field value={notes} onChangeText={setNotes} placeholder="Como foi o treino?" multiline />
        <Button title="Registrar treino" onPress={save} />
      </Card>
      <Text style={{ color: C.text, fontSize: 18, fontWeight: '900', marginVertical: 10 }}>Histórico</Text>
      {items.length === 0 ? <Text style={{ color: C.muted }}>Seus treinos registrados aparecerão aqui.</Text> : items.map(item =>
        <Card key={item.id}>
          <Text style={{ color: C.text, fontWeight: '800', fontSize: 16 }}>{item.title}</Text>
          <Text style={{ color: C.muted, marginTop: 5 }}>{item.category} • {item.duration_minutes} min</Text>
          <Text style={{ color: C.muted, fontSize: 11, marginTop: 5 }}>{new Date(item.date).toLocaleString('pt-BR')}</Text>
          {!!item.notes && <Text style={{ color: C.text, marginTop: 8 }}>{item.notes}</Text>}
        </Card>
      )}
    </ScrollView>
  </Screen>;
}
