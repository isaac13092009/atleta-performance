import React, { useState } from 'react';
import { View, Text, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { router } from 'expo-router';
import { Screen, Heading, Card, Field, Button, Label } from '../components/ui';
import { C } from '../lib/theme';
import { supabase, isSupabaseConfigured } from '../lib/supabase';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);

  async function signIn() {
    if (!email.trim() || !password) return Alert.alert('Preencha os campos', 'Informe e-mail e senha.');
    if (!supabase) {
      Alert.alert('Configuração necessária', 'Configure o Supabase no arquivo .env para ativar contas e sincronização. Você pode abrir a demonstração local.');
      router.replace('/(tabs)');
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setBusy(false);
    if (error) Alert.alert('Não foi possível entrar', error.message);
    else router.replace('/(tabs)');
  }

  async function signUp() {
    if (!email.trim() || !password) return Alert.alert('Preencha os campos', 'Informe e-mail e senha.');
    if (password.length < 8) return Alert.alert('Senha curta', 'Use pelo menos 8 caracteres.');
    if (!supabase) return Alert.alert('Supabase não configurado', 'Adicione as credenciais do seu projeto Supabase ao .env.');
    setBusy(true);
    const { error } = await supabase.auth.signUp({ email: email.trim(), password });
    setBusy(false);
    Alert.alert(error ? 'Erro no cadastro' : 'Cadastro iniciado', error?.message || 'Verifique seu e-mail, se a confirmação estiver ativada.');
  }

  return <Screen>
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, justifyContent: 'center' }}>
      <View style={{ marginBottom: 28 }}>
        <Text style={{ color: C.blueLight, letterSpacing: 4, fontWeight: '900', fontSize: 12 }}>ATHLETE</Text>
        <Text style={{ color: C.text, fontSize: 36, fontWeight: '900', letterSpacing: -1 }}>PERFORMANCE</Text>
        <Text style={{ color: C.muted, marginTop: 8 }}>Your training. Your game. Your evolution.</Text>
      </View>
      <Card>
        <Heading eyebrow="Área do atleta" title="Acesse sua conta" subtitle="Entre para acompanhar sua evolução." />
        <Label>E-mail</Label>
        <Field value={email} onChangeText={setEmail} placeholder="seu@email.com" keyboardType="email-address" autoCapitalize="none" />
        <Label>Senha</Label>
        <Field value={password} onChangeText={setPassword} placeholder="Mínimo de 8 caracteres" secureTextEntry />
        <Button title={busy ? 'Aguarde...' : 'Entrar'} onPress={signIn} />
        <Button title="Criar conta" onPress={signUp} secondary />
      </Card>
      <Text style={{ color: C.muted, textAlign: 'center', fontSize: 11 }}>
        {isSupabaseConfigured ? 'Sincronização em nuvem configurada' : 'Modo de demonstração local • Configure o Supabase para persistência em nuvem'}
      </Text>
    </KeyboardAvoidingView>
  </Screen>;
}
