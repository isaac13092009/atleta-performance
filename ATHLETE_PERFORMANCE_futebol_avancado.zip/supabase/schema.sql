-- ATHLETE PERFORMANCE — Supabase schema
-- Execute no SQL Editor do seu projeto Supabase.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  age integer check (age is null or age between 13 and 100),
  height_cm numeric(5,2),
  weight_kg numeric(5,2),
  football_position text,
  created_at timestamptz not null default now()
);

create table if not exists public.workout_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  category text not null default 'Musculação',
  date timestamptz not null default now(),
  duration_minutes integer not null default 60 check (duration_minutes > 0),
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.exercises (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  muscle_group text,
  created_at timestamptz not null default now()
);

create table if not exists public.exercise_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  workout_session_id uuid references public.workout_sessions(id) on delete set null,
  exercise_id uuid references public.exercises(id) on delete set null,
  sets integer not null default 3,
  reps integer not null default 10,
  load_kg numeric(7,2),
  rest_seconds integer,
  created_at timestamptz not null default now()
);

create table if not exists public.body_metrics (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  weight_kg numeric(6,2) not null,
  measured_at timestamptz not null default now()
);

create table if not exists public.football_matches (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  opponent text not null,
  match_date timestamptz not null default now(),
  minutes_played integer not null default 0 check (minutes_played >= 0),
  goals integer not null default 0 check (goals >= 0),
  assists integer not null default 0 check (assists >= 0),
  result text,
  competition text,
  season text,
  venue text,
  position text,
  started_as text not null default 'Titular' check (started_as in ('Titular','Reserva')),
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.football_goal_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  match_id uuid not null references public.football_matches(id) on delete cascade,
  minute integer not null check (minute between 0 and 150),
  goal_type text not null default 'Jogada',
  foot text not null default 'Direito',
  assisted_by text,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.calendar_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  event_type text not null default 'Treino',
  starts_at timestamptz not null,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.sleep_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  sleep_start timestamptz,
  sleep_end timestamptz,
  duration_minutes integer check (duration_minutes is null or duration_minutes >= 0),
  source text not null default 'manual',
  created_at timestamptz not null default now()
);

create table if not exists public.recovery_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  perceived_fatigue integer check (perceived_fatigue between 1 and 10),
  muscle_soreness integer check (muscle_soreness between 1 and 10),
  notes text,
  recorded_at timestamptz not null default now()
);

create table if not exists public.integrations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  provider text not null,
  status text not null default 'disconnected',
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(user_id, provider)
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  body text not null,
  scheduled_for timestamptz,
  sent_at timestamptz,
  created_at timestamptz not null default now()
);

-- Row Level Security: cada usuário acessa somente seus próprios registros.
do $$
declare t text;
begin
  foreach t in array array[
    'profiles','workout_sessions','exercises','exercise_logs','body_metrics',
    'football_matches','football_goal_events','calendar_events','sleep_records','recovery_records',
    'integrations','notifications'
  ] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists "user owns rows" on public.%I', t);
    execute format(
      'create policy "user owns rows" on public.%I for all using (auth.uid() = id or auth.uid() = user_id) with check (auth.uid() = id or auth.uid() = user_id)',
      t
    );
  end loop;
end $$;

-- Perfil usa o id do usuário autenticado; demais tabelas usam user_id.
drop policy if exists "user owns rows" on public.profiles;
create policy "user owns profile" on public.profiles
  for all using (auth.uid() = id) with check (auth.uid() = id);

create index if not exists workout_sessions_user_date_idx on public.workout_sessions(user_id, date desc);
create index if not exists football_matches_user_date_idx on public.football_matches(user_id, match_date desc);
create index if not exists football_goal_events_user_match_idx on public.football_goal_events(user_id, match_id, minute);
create index if not exists calendar_events_user_start_idx on public.calendar_events(user_id, starts_at);
