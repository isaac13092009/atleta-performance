import React from 'react';
import { View, Text, TextInput, TouchableOpacity, ViewStyle, TextInputProps } from 'react-native';
import { C } from '../lib/theme';

export function Screen({ children }: { children: React.ReactNode }) {
  return <View style={{ flex: 1, backgroundColor: C.bg, paddingHorizontal: 20, paddingTop: 18 }}>{children}</View>;
}
export function Heading({ eyebrow, title, subtitle }: { eyebrow?: string; title: string; subtitle?: string }) {
  return <View style={{ marginBottom: 22 }}>
    {!!eyebrow && <Text style={{ color: C.blueLight, fontSize: 11, fontWeight: '800', letterSpacing: 2, marginBottom: 8 }}>{eyebrow.toUpperCase()}</Text>}
    <Text style={{ color: C.text, fontSize: 28, fontWeight: '900', letterSpacing: -0.6 }}>{title}</Text>
    {!!subtitle && <Text style={{ color: C.muted, marginTop: 6, fontSize: 13 }}>{subtitle}</Text>}
  </View>;
}
export function Card({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return <View style={[{ backgroundColor: C.panel, borderWidth: 1, borderColor: C.line, borderRadius: 18, padding: 16, marginBottom: 12 }, style]}>{children}</View>;
}
export function Label({ children }: { children: React.ReactNode }) {
  return <Text style={{ color: C.muted, fontSize: 12, fontWeight: '700', marginBottom: 7 }}>{children}</Text>;
}
export function Field(props: TextInputProps) {
  return <TextInput placeholderTextColor={C.muted} {...props}
    style={[{ backgroundColor: C.panel2, borderColor: C.line, borderWidth: 1, borderRadius: 12, color: C.text, paddingHorizontal: 13, paddingVertical: 13, marginBottom: 12 }, props.style]} />;
}
export function Button({ title, onPress, secondary = false }: { title: string; onPress: () => void; secondary?: boolean }) {
  return <TouchableOpacity onPress={onPress} style={{ backgroundColor: secondary ? C.panel2 : C.blue, borderRadius: 13, padding: 15, alignItems: 'center', borderWidth: secondary ? 1 : 0, borderColor: C.line, marginTop: 4 }}>
    <Text style={{ color: C.text, fontWeight: '800' }}>{title}</Text>
  </TouchableOpacity>;
}
export function Stat({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return <Card style={{ flex: 1, minWidth: 135 }}>
    <Text style={{ color: C.muted, fontSize: 11, fontWeight: '700' }}>{label.toUpperCase()}</Text>
    <Text style={{ color: C.text, fontSize: 25, fontWeight: '900', marginTop: 8 }}>{value}</Text>
    {!!hint && <Text style={{ color: C.muted, fontSize: 11, marginTop: 4 }}>{hint}</Text>}
  </Card>;
}
